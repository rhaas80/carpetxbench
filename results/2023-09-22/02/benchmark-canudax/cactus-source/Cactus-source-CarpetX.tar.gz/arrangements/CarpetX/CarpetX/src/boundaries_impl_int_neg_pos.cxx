#include "boundaries_impl.hxx"

namespace CarpetX {

template void BoundaryCondition::apply_on_face<INT, NEG, POS>() const;

} // namespace CarpetX
