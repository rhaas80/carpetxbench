// evolve_utils: Misc stuff that is needed for evolution!
//
//=============================================================================

#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "loop_device.hxx"
#include "evolve_utils.hxx"

using namespace CanudaX_BSSNMoL;

namespace CanudaX_BSSNMoL{

using namespace std;
using namespace Loop;

template <typename T> int sgn(T val) {
    return (T(0) < val) - (val < T(0));
}


//void det_metric(CCTK_REAL& dethh, CCTK_REAL (&hh) [3][3])
//{
//  // NOTE: deth = 1 by construction, but that is not satisfied numerically
//  //if (hh[0][0] == 0) CCTK_VERROR("hh = %g in det_metric", hh[0][0]);
//  dethh =     hh[0][0] * hh[1][1] * hh[2][2]
//        + 2 * hh[0][1] * hh[0][2] * hh[1][2]
//        -     hh[0][0] * hh[1][2] * hh[1][2]
//        -     hh[1][1] * hh[0][2] * hh[0][2]
//        -     hh[2][2] * hh[0][1] * hh[0][1];
//}
//
//void invert_metric(CCTK_REAL (&hu) [3][3], CCTK_REAL (&hh) [3][3])
//{
//  CCTK_REAL dethh;
//
//  //------------ Invert metric ----------------
//  det_metric(dethh, hh);
//  if (dethh == 0) CCTK_VERROR("dethh = %g in invert_metric", dethh);
//
//  hu[0][0] = (hh[1][1] * hh[2][2] - hh[1][2] * hh[1][2]) / dethh;
//  hu[1][1] = (hh[0][0] * hh[2][2] - hh[0][2] * hh[0][2]) / dethh;
//  hu[2][2] = (hh[0][0] * hh[1][1] - hh[0][1] * hh[0][1]) / dethh;
//  hu[0][1] = (hh[0][2] * hh[1][2] - hh[0][1] * hh[2][2]) / dethh;
//  hu[0][2] = (hh[0][1] * hh[1][2] - hh[0][2] * hh[1][1]) / dethh;
//  hu[1][2] = (hh[0][2] * hh[0][1] - hh[1][2] * hh[0][0]) / dethh;
//  hu[1][0] = hu[0][1];
//  hu[2][0] = hu[0][2];
//  hu[2][1] = hu[1][2];
//  //-------------------------------------------
//}

void apply_jacobian(CCTK_REAL dvar[3], CCTK_REAL jac[3][3])
{

  CCTK_REAL xdvar[3];
  CCTK_INT  a, b;

  for (a=0; a<3; a++) {
    xdvar[a] = 0;
    for (b=0; b<3; b++) {
        xdvar[a] = xdvar[a] + dvar[b] * jac[b][a];
    }
  }

  for (a=0; a<3; a++) {
    dvar[a] = xdvar[a];
  }

}

void apply_jacobian2(CCTK_REAL ddvar[3][3], CCTK_REAL dvar[3], CCTK_REAL jac[3][3], CCTK_REAL hes[3][3][3])
{

  CCTK_REAL xddvar[3][3], xdvar[3];
  CCTK_INT  a, b, c, d;

  for (a=0; a<3; a++) { xdvar[a] = 0;
    for (b=0; b<3; b++) {
      xdvar[a] = xdvar[a] + dvar[b] * jac[b][a];
    }
  }

  for (a=0; a<3; a++) {
    for (b=0; b<3; b++) {
      xddvar[a][b] = 0;
      for (c=0; c<3; c++) {
        xddvar[a][b] = xddvar[a][b] + dvar[c] * hes[c][a][b];
        for (d=0; d<3; d++) {
          xddvar[a][b] = xddvar[a][b] + ddvar[c][d] * jac[c][a] * jac[d][b];
        }
      }
    }
  }

  for (a=0; a<3; a++) {
    dvar[a] = xdvar[a];
    for (b=0; b<3; b++) {
      ddvar[a][b] = xddvar[a][b];
    }
  }

}

} // namespace CanudaX_BSSNMoL

void LeanBSSN_remove_trA( CCTK_ARGUMENTS )
{

  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_remove_trA;
  DECLARE_CCTK_PARAMETERS;

  grid.loop_int_device<0, 0, 0>(
      grid.nghostzones,
      [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
          CCTK_ATTRIBUTE_ALWAYS_INLINE {

          CCTK_REAL hhDD[3][3], aaDD[3][3], hhUU[3][3], dethh;
          CCTK_REAL tr_aa;
          CCTK_INT  m, n;

          hhDD[0][0] = hxx(p.I);
          hhDD[0][1] = hxy(p.I);
          hhDD[0][2] = hxz(p.I);
          hhDD[1][1] = hyy(p.I);
          hhDD[1][2] = hyz(p.I);
          hhDD[2][2] = hzz(p.I);
          hhDD[1][0] = hhDD[0][1];
          hhDD[2][0] = hhDD[0][2];
          hhDD[2][1] = hhDD[1][2];

          aaDD[0][0] = axx(p.I);
          aaDD[0][1] = axy(p.I);
          aaDD[0][2] = axz(p.I);
          aaDD[1][1] = ayy(p.I);
          aaDD[1][2] = ayz(p.I);
          aaDD[2][2] = azz(p.I);
          aaDD[1][0] = aaDD[0][1];
          aaDD[2][0] = aaDD[0][2];
          aaDD[2][1] = aaDD[1][2];

          //invert_metric(hu, hh);
          dethh =     hhDD[0][0] * hhDD[1][1] * hhDD[2][2]
                + 2 * hhDD[0][1] * hhDD[0][2] * hhDD[1][2]
                -     hhDD[0][0] * hhDD[1][2] * hhDD[1][2]
                -     hhDD[1][1] * hhDD[0][2] * hhDD[0][2]
                -     hhDD[2][2] * hhDD[0][1] * hhDD[0][1];
          if(dethh != 0){
            hhUU[0][0] = (hhDD[1][1] * hhDD[2][2] - hhDD[1][2] * hhDD[1][2]) / dethh;
            hhUU[1][1] = (hhDD[0][0] * hhDD[2][2] - hhDD[0][2] * hhDD[0][2]) / dethh;
            hhUU[2][2] = (hhDD[0][0] * hhDD[1][1] - hhDD[0][1] * hhDD[0][1]) / dethh;
            hhUU[0][1] = (hhDD[0][2] * hhDD[1][2] - hhDD[0][1] * hhDD[2][2]) / dethh;
            hhUU[0][2] = (hhDD[0][1] * hhDD[1][2] - hhDD[0][2] * hhDD[1][1]) / dethh;
            hhUU[1][2] = (hhDD[0][2] * hhDD[0][1] - hhDD[1][2] * hhDD[0][0]) / dethh;
            hhUU[1][0] = hhUU[0][1];
            hhUU[2][0] = hhUU[0][2];
            hhUU[2][1] = hhUU[1][2];
          }

          tr_aa = 0;
          for (m=0; m<3; m++) {
            for (n=0; n<3; n++) {
              tr_aa += hhUU[m][n] * aaDD[m][n];
            }
          }

          for (m=0; m<3; m++) {
            for (n=0; n<3; n++) {
              aaDD[m][n] -= hhDD[m][n] * tr_aa / 3;
            }
          }

          axx(p.I) = aaDD[0][0];
          axy(p.I) = aaDD[0][1];
          axz(p.I) = aaDD[0][2];
          ayy(p.I) = aaDD[1][1];
          ayz(p.I) = aaDD[1][2];
          azz(p.I) = aaDD[2][2];
  });

}

void LeanBSSN_reset_detmetric( CCTK_ARGUMENTS )
{

  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_reset_detmetric;
  DECLARE_CCTK_PARAMETERS;

  grid.loop_int_device<0, 0, 0>(
      grid.nghostzones,
      [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
          CCTK_ATTRIBUTE_ALWAYS_INLINE {

          CCTK_REAL hhDD[3][3];
          CCTK_REAL dethh;
          CCTK_INT  m, n;

          hhDD[0][0] = hxx(p.I);
          hhDD[0][1] = hxy(p.I);
          hhDD[0][2] = hxz(p.I);
          hhDD[1][1] = hyy(p.I);
          hhDD[1][2] = hyz(p.I);
          hhDD[2][2] = hzz(p.I);
          hhDD[1][0] = hhDD[0][1];
          hhDD[2][0] = hhDD[0][2];
          hhDD[2][1] = hhDD[1][2];

          //det_metric(dethh, hh);
          dethh =     hhDD[0][0] * hhDD[1][1] * hhDD[2][2]
                + 2 * hhDD[0][1] * hhDD[0][2] * hhDD[1][2]
                -     hhDD[0][0] * hhDD[1][2] * hhDD[1][2]
                -     hhDD[1][1] * hhDD[0][2] * hhDD[0][2]
                -     hhDD[2][2] * hhDD[0][1] * hhDD[0][1];
          if(dethh != 0){
            for (m=0; m<3; m++) {
              for (n=0; n<3; n++) {
                hhDD[m][n] /= pow(dethh, (1.0/3.0));
              }
            }
          }

          hxx(p.I) = hhDD[0][0];
          hxy(p.I) = hhDD[0][1];
          hxz(p.I) = hhDD[0][2];
          hyy(p.I) = hhDD[1][1];
          hyz(p.I) = hhDD[1][2];
          hzz(p.I) = hhDD[2][2];
  });

}

void LeanBSSN_impose_conf_fac_floor( CCTK_ARGUMENTS )
{

  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_impose_conf_fac_floor;
  DECLARE_CCTK_PARAMETERS;

  grid.loop_int_device<0, 0, 0>(
      grid.nghostzones,
      [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
          CCTK_ATTRIBUTE_ALWAYS_INLINE {

        if( conf_fac(p.I) < conf_fac_floor )
            conf_fac(p.I) = conf_fac_floor;

  });
}
