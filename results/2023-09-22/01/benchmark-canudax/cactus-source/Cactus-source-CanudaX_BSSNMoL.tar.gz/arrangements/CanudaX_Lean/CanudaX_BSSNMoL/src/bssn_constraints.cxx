// bssn_constraints.F90
//
//=============================================================================

#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "loop_device.hxx"
#include "evolve_utils.hxx"

// 1st derivative - 6th order
#define FD_DX_VI(gf) \
  ( + gf(Ip3dx) - 9*gf(Ip2dx) + 45*gf(Ip1dx) - 45*gf(Im1dx) + 9*gf(Im2dx) - gf(Im3dx) ) * inv60dx
#define FD_DY_VI(gf) \
  ( + gf(Ip3dy) - 9*gf(Ip2dy) + 45*gf(Ip1dy) - 45*gf(Im1dy) + 9*gf(Im2dy) - gf(Im3dy) ) * inv60dy
#define FD_DZ_VI(gf) \
  ( + gf(Ip3dz) - 9*gf(Ip2dz) + 45*gf(Ip1dz) - 45*gf(Im1dz) + 9*gf(Im2dz) - gf(Im3dz) ) * inv60dz
// 2nd derivative - DIDI - 6th order
#define FD_DXDX_VI(gf) \
  ( + 2*gf(Ip3dx) - 27*gf(Ip2dx) + 270*gf(Ip1dx) - 490*gf(p.I) + 270*gf(Im1dx) - 27*gf(Im2dx) + 2*gf(Im3dx) ) * inv180dxsq
#define FD_DYDY_VI(gf) \
  ( + 2*gf(Ip3dy) - 27*gf(Ip2dy) + 270*gf(Ip1dy) - 490*gf(p.I) + 270*gf(Im1dy) - 27*gf(Im2dy) + 2*gf(Im3dy) ) * inv180dysq
#define FD_DZDZ_VI(gf) \
  ( + 2*gf(Ip3dz) - 27*gf(Ip2dz) + 270*gf(Ip1dz) - 490*gf(p.I) + 270*gf(Im1dz) - 27*gf(Im2dz) + 2*gf(Im3dz) ) * inv180dzsq
// 2nd derivative - DIDI - 6th order
#define FD_DXDY_VI(gf) \
  ( -    gf(Im3dxp3dy) +   9*gf(Im3dxp2dy) -   45*gf(Im3dxp1dy) +   45*gf(Im3dxm1dy) -   9*gf(Im3dxm2dy) +    gf(Im3dxm3dy) \
    +  9*gf(Im2dxp3dy) -  81*gf(Im2dxp2dy) +  405*gf(Im2dxp1dy) -  405*gf(Im2dxm1dy) +  81*gf(Im2dxm2dy) -  9*gf(Im2dxm3dy) \
    - 45*gf(Im1dxp3dy) + 405*gf(Im1dxp2dy) - 2025*gf(Im1dxp1dy) + 2025*gf(Im1dxm1dy) - 405*gf(Im1dxm2dy) + 45*gf(Im1dxm3dy) \
    + 45*gf(Ip1dxp3dy) - 405*gf(Ip1dxp2dy) + 2025*gf(Ip1dxp1dy) - 2025*gf(Ip1dxm1dy) + 405*gf(Ip1dxm2dy) - 45*gf(Ip1dxm3dy) \
    -  9*gf(Ip2dxp3dy) +  81*gf(Ip2dxp2dy) -  405*gf(Ip2dxp1dy) +  405*gf(Ip2dxm1dy) -  81*gf(Ip2dxm2dy) +  9*gf(Ip2dxm3dy) \
    +    gf(Ip3dxp3dy) -   9*gf(Ip3dxp2dy) +   45*gf(Ip3dxp1dy) -   45*gf(Ip3dxm1dy) +   9*gf(Ip3dxm2dy) -    gf(Ip3dxm3dy) \
  ) * inv3600dxdy
#define FD_DXDZ_VI(gf) \
  ( -    gf(Im3dxp3dz) +   9*gf(Im3dxp2dz) -   45*gf(Im3dxp1dz) +   45*gf(Im3dxm1dz) -   9*gf(Im3dxm2dz) +    gf(Im3dxm3dz) \
    +  9*gf(Im2dxp3dz) -  81*gf(Im2dxp2dz) +  405*gf(Im2dxp1dz) -  405*gf(Im2dxm1dz) +  81*gf(Im2dxm2dz) -  9*gf(Im2dxm3dz) \
    - 45*gf(Im1dxp3dz) + 405*gf(Im1dxp2dz) - 2025*gf(Im1dxp1dz) + 2025*gf(Im1dxm1dz) - 405*gf(Im1dxm2dz) + 45*gf(Im1dxm3dz) \
    + 45*gf(Ip1dxp3dz) - 405*gf(Ip1dxp2dz) + 2025*gf(Ip1dxp1dz) - 2025*gf(Ip1dxm1dz) + 405*gf(Ip1dxm2dz) - 45*gf(Ip1dxm3dz) \
    -  9*gf(Ip2dxp3dz) +  81*gf(Ip2dxp2dz) -  405*gf(Ip2dxp1dz) +  405*gf(Ip2dxm1dz) -  81*gf(Ip2dxm2dz) +  9*gf(Ip2dxm3dz) \
    +    gf(Ip3dxp3dz) -   9*gf(Ip3dxp2dz) +   45*gf(Ip3dxp1dz) -   45*gf(Ip3dxm1dz) +   9*gf(Ip3dxm2dz) -    gf(Ip3dxm3dz) \
  ) * inv3600dxdz
#define FD_DYDZ_VI(gf) \
  ( -    gf(Im3dyp3dz) +   9*gf(Im3dyp2dz) -   45*gf(Im3dyp1dz) +   45*gf(Im3dym1dz) -   9*gf(Im3dym2dz) +    gf(Im3dym3dz) \
    +  9*gf(Im2dyp3dz) -  81*gf(Im2dyp2dz) +  405*gf(Im2dyp1dz) -  405*gf(Im2dym1dz) +  81*gf(Im2dym2dz) -  9*gf(Im2dym3dz) \
    - 45*gf(Im1dyp3dz) + 405*gf(Im1dyp2dz) - 2025*gf(Im1dyp1dz) + 2025*gf(Im1dym1dz) - 405*gf(Im1dym2dz) + 45*gf(Im1dym3dz) \
    + 45*gf(Ip1dyp3dz) - 405*gf(Ip1dyp2dz) + 2025*gf(Ip1dyp1dz) - 2025*gf(Ip1dym1dz) + 405*gf(Ip1dym2dz) - 45*gf(Ip1dym3dz) \
    -  9*gf(Ip2dyp3dz) +  81*gf(Ip2dyp2dz) -  405*gf(Ip2dyp1dz) +  405*gf(Ip2dym1dz) -  81*gf(Ip2dym2dz) +  9*gf(Ip2dym3dz) \
    +    gf(Ip3dyp3dz) -   9*gf(Ip3dyp2dz) +   45*gf(Ip3dyp1dz) -   45*gf(Ip3dym1dz) +   9*gf(Ip3dym2dz) -    gf(Ip3dym3dz) \
  ) * inv3600dydz
// 1st derivative - 4th order
#define FD_DX_IV(gf) \
  ( - gf(Ip2dx) + 8*gf(Ip1dx) - 8*gf(Im1dx) + gf(Im2dx) ) * inv12dx
#define FD_DY_IV(gf) \
  ( - gf(Ip2dy) + 8*gf(Ip1dy) - 8*gf(Im1dy) + gf(Im2dy) ) * inv12dy
#define FD_DZ_IV(gf) \
  ( - gf(Ip2dz) + 8*gf(Ip1dz) - 8*gf(Im1dz) + gf(Im2dz) ) * inv12dz
// 2nd derivative - DIDI - 4th order
#define FD_DXDX_IV(gf) \
  ( - gf(Ip2dx) + 16*gf(Ip1dx) - 30*gf(p.I) + 16*gf(Im1dx) - gf(Im2dx) ) * inv12dxsq
#define FD_DYDY_IV(gf) \
  ( - gf(Ip2dy) + 16*gf(Ip1dy) - 30*gf(p.I) + 16*gf(Im1dy) - gf(Im2dy) ) * inv12dysq
#define FD_DZDZ_IV(gf) \
  ( - gf(Ip2dz) + 16*gf(Ip1dz) - 30*gf(p.I) + 16*gf(Im1dz) - gf(Im2dz) ) * inv12dzsq
// 2nd derivative - DIDJ - 4th order
#define FD_DXDY_IV(gf) \
  ( -   gf(Im2dxp2dy) +  8*gf(Im2dxp1dy) -  8*gf(Im2dxm1dy) +   gf(Im2dxm2dy) \
    + 8*gf(Im1dxp2dy) - 64*gf(Im1dxp1dy) + 64*gf(Im1dxm1dy) - 8*gf(Im1dxm2dy) \
    - 8*gf(Ip1dxp2dy) + 64*gf(Ip1dxp1dy) - 64*gf(Ip1dxm1dy) + 8*gf(Ip1dxm2dy) \
    +   gf(Ip2dxp2dy) -  8*gf(Ip2dxp1dy) +  8*gf(Ip2dxm1dy) -   gf(Ip2dxm2dy) \
  ) * inv144dxdy
#define FD_DXDZ_IV(gf) \
  ( -   gf(Im2dxp2dz) +  8*gf(Im2dxp1dz) -  8*gf(Im2dxm1dz) +   gf(Im2dxm2dz) \
    + 8*gf(Im1dxp2dz) - 64*gf(Im1dxp1dz) + 64*gf(Im1dxm1dz) - 8*gf(Im1dxm2dz) \
    - 8*gf(Ip1dxp2dz) + 64*gf(Ip1dxp1dz) - 64*gf(Ip1dxm1dz) + 8*gf(Ip1dxm2dz) \
    +   gf(Ip2dxp2dz) -  8*gf(Ip2dxp1dz) +  8*gf(Ip2dxm1dz) -   gf(Ip2dxm2dz) \
  ) * inv144dxdz
#define FD_DYDZ_IV(gf) \
  ( -   gf(Im2dyp2dz) +  8*gf(Im2dyp1dz) -  8*gf(Im2dym1dz) +   gf(Im2dym2dz) \
    + 8*gf(Im1dyp2dz) - 64*gf(Im1dyp1dz) + 64*gf(Im1dym1dz) - 8*gf(Im1dym2dz) \
    - 8*gf(Ip1dyp2dz) + 64*gf(Ip1dyp1dz) - 64*gf(Ip1dym1dz) + 8*gf(Ip1dym2dz) \
    +   gf(Ip2dyp2dz) -  8*gf(Ip2dyp1dz) +  8*gf(Ip2dym1dz) -   gf(Ip2dym2dz) \
  ) * inv144dydz

using namespace std;
using namespace Loop;
using namespace CanudaX_BSSNMoL;

template <int FD_order> void LeanBSSN_bssn_constraints_body( CCTK_ARGUMENTS ) {

  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_bssn_constraints;
  DECLARE_CCTK_PARAMETERS;

  if (cctk_iteration % calculate_constraints_every != 0 )
     return;

  grid.loop_int_device<0, 0, 0>(
      grid.nghostzones,
      [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
          CCTK_ATTRIBUTE_ALWAYS_INLINE {

    //define local copies of fundamental variables
    CCTK_REAL alph, betaU[3], ww, hhDD[3][3];
    CCTK_REAL trk, aaDD[3][3], gammatU[3];

    // Matter variables
    CCTK_REAL Tab[4][4];
    CCTK_REAL srcE, srcjdi[3];

    //define other aux variables
    CCTK_REAL hhUU[3][3], dethh;
    CCTK_REAL aaDU_aaDD[3][3];
    CCTK_REAL sq_aa;
    CCTK_REAL cf1[3][3][3], cf2[3][3][3]; //Christoffel symbols of \tilde{\gamma}_{ij}
    CCTK_REAL c_ri[3][3], c_ri_ww[3][3], c_ri_hh[3][3];
    CCTK_REAL ri_1[3][3], ri_2[3][3], ri_3[3][3];
    CCTK_REAL tr_cd2_ww, tr_dww_dww, trr;

    //define local variables for first order derivatives
    CCTK_REAL d1_ww[3];
    CCTK_REAL d1_hh11[3], d1_hh12[3], d1_hh13[3], d1_hh22[3];
    CCTK_REAL d1_hh23[3], d1_hh33[3], d1_hhDD[3][3][3];
    CCTK_REAL d1_trk[3];
    CCTK_REAL d1_aa11[3], d1_aa12[3], d1_aa13[3], d1_aa22[3];
    CCTK_REAL d1_aa23[3], d1_aa33[3], d1_aaDD[3][3][3];
    CCTK_REAL d1_gammat1[3], d1_gammat2[3], d1_gammat3[3], d1_gammatU[3][3];

    //define local variables for second order derivatives
    CCTK_REAL d2_ww[3][3];
    CCTK_REAL d2_hh11[3][3], d2_hh12[3][3], d2_hh13[3][3], d2_hh22[3][3];
    CCTK_REAL d2_hh23[3][3], d2_hh33[3][3], d2_hhDD[3][3][3][3];

    // Covariant derivatives
    CCTK_REAL                cd2_ww[3][3], cd1_aaDD[3][3][3];

    // Constraints
    CCTK_REAL                ham, mom[3];

    // Misc variables
    const CCTK_REAL          one  = 1;
    const CCTK_REAL          pi   = acos(-one);
    const CCTK_REAL          pi8  = 8*pi;
    const CCTK_REAL          pi16 = 16*pi;
    CCTK_INT                 a, b, c, d, i, j, k, l, m, n;

    // make sure there are no uninitialised values anywhere
    hc(p.I)  = 0;
    mcx(p.I) = 0;
    mcy(p.I) = 0;
    mcz(p.I) = 0;

    //------------ Get local variables ----------
    ww        = conf_fac(p.I);

    hhDD[0][0]  = hxx(p.I);
    hhDD[0][1]  = hxy(p.I);
    hhDD[0][2]  = hxz(p.I);
    hhDD[1][1]  = hyy(p.I);
    hhDD[1][2]  = hyz(p.I);
    hhDD[2][2]  = hzz(p.I);
    hhDD[1][0]  = hhDD[0][1];
    hhDD[2][0]  = hhDD[0][2];
    hhDD[2][1]  = hhDD[1][2];

    trk       = tracek(p.I);

    aaDD[0][0]  = axx(p.I);
    aaDD[0][1]  = axy(p.I);
    aaDD[0][2]  = axz(p.I);
    aaDD[1][1]  = ayy(p.I);
    aaDD[1][2]  = ayz(p.I);
    aaDD[2][2]  = azz(p.I);
    aaDD[1][0]  = aaDD[0][1];
    aaDD[2][0]  = aaDD[0][2];
    aaDD[2][1]  = aaDD[1][2];

    gammatU[0] = gammatx(p.I);
    gammatU[1] = gammaty(p.I);
    gammatU[2] = gammatz(p.I);

    alph      = alpha(p.I);

    betaU[0]   = betx(p.I);
    betaU[1]   = bety(p.I);
    betaU[2]   = betz(p.I);

    //------------- indices-------------
    vect<int, 3> Ip3dx = p.I + 3*p.DI[0];
    vect<int, 3> Ip3dy = p.I + 3*p.DI[1];
    vect<int, 3> Ip3dz = p.I + 3*p.DI[2];
    vect<int, 3> Ip2dx = p.I + 2*p.DI[0];
    vect<int, 3> Ip2dy = p.I + 2*p.DI[1];
    vect<int, 3> Ip2dz = p.I + 2*p.DI[2];
    vect<int, 3> Ip1dx = p.I +   p.DI[0];
    vect<int, 3> Ip1dy = p.I +   p.DI[1];
    vect<int, 3> Ip1dz = p.I +   p.DI[2];
    vect<int, 3> Im3dx = p.I - 3*p.DI[0];
    vect<int, 3> Im3dy = p.I - 3*p.DI[1];
    vect<int, 3> Im3dz = p.I - 3*p.DI[2];
    vect<int, 3> Im2dx = p.I - 2*p.DI[0];
    vect<int, 3> Im2dy = p.I - 2*p.DI[1];
    vect<int, 3> Im2dz = p.I - 2*p.DI[2];
    vect<int, 3> Im1dx = p.I -   p.DI[0];
    vect<int, 3> Im1dy = p.I -   p.DI[1];
    vect<int, 3> Im1dz = p.I -   p.DI[2];

    vect<int, 3> Ip3dxp3dy = p.I + 3*p.DI[0] + 3*p.DI[1];
    vect<int, 3> Ip3dxp2dy = p.I + 3*p.DI[0] + 2*p.DI[1];
    vect<int, 3> Ip3dxp1dy = p.I + 3*p.DI[0] +   p.DI[1];
    vect<int, 3> Ip3dxm3dy = p.I + 3*p.DI[0] - 3*p.DI[1];
    vect<int, 3> Ip3dxm2dy = p.I + 3*p.DI[0] - 2*p.DI[1];
    vect<int, 3> Ip3dxm1dy = p.I + 3*p.DI[0] -   p.DI[1];
    vect<int, 3> Ip3dxp3dz = p.I + 3*p.DI[0] + 3*p.DI[2];
    vect<int, 3> Ip3dxp2dz = p.I + 3*p.DI[0] + 2*p.DI[2];
    vect<int, 3> Ip3dxp1dz = p.I + 3*p.DI[0] +   p.DI[2];
    vect<int, 3> Ip3dxm3dz = p.I + 3*p.DI[0] - 3*p.DI[2];
    vect<int, 3> Ip3dxm2dz = p.I + 3*p.DI[0] - 2*p.DI[2];
    vect<int, 3> Ip3dxm1dz = p.I + 3*p.DI[0] -   p.DI[2];

    vect<int, 3> Ip2dxp3dy = p.I + 2*p.DI[0] + 3*p.DI[1];
    vect<int, 3> Ip2dxp2dy = p.I + 2*p.DI[0] + 2*p.DI[1];
    vect<int, 3> Ip2dxp1dy = p.I + 2*p.DI[0] +   p.DI[1];
    vect<int, 3> Ip2dxm3dy = p.I + 2*p.DI[0] - 3*p.DI[1];
    vect<int, 3> Ip2dxm2dy = p.I + 2*p.DI[0] - 2*p.DI[1];
    vect<int, 3> Ip2dxm1dy = p.I + 2*p.DI[0] -   p.DI[1];
    vect<int, 3> Ip2dxp3dz = p.I + 2*p.DI[0] + 3*p.DI[2];
    vect<int, 3> Ip2dxp2dz = p.I + 2*p.DI[0] + 2*p.DI[2];
    vect<int, 3> Ip2dxp1dz = p.I + 2*p.DI[0] +   p.DI[2];
    vect<int, 3> Ip2dxm3dz = p.I + 2*p.DI[0] - 3*p.DI[2];
    vect<int, 3> Ip2dxm2dz = p.I + 2*p.DI[0] - 2*p.DI[2];
    vect<int, 3> Ip2dxm1dz = p.I + 2*p.DI[0] -   p.DI[2];

    vect<int, 3> Ip1dxp3dy = p.I +   p.DI[0] + 3*p.DI[1];
    vect<int, 3> Ip1dxp2dy = p.I +   p.DI[0] + 2*p.DI[1];
    vect<int, 3> Ip1dxp1dy = p.I +   p.DI[0] +   p.DI[1];
    vect<int, 3> Ip1dxm3dy = p.I +   p.DI[0] - 3*p.DI[1];
    vect<int, 3> Ip1dxm2dy = p.I +   p.DI[0] - 2*p.DI[1];
    vect<int, 3> Ip1dxm1dy = p.I +   p.DI[0] -   p.DI[1];
    vect<int, 3> Ip1dxp3dz = p.I +   p.DI[0] + 3*p.DI[2];
    vect<int, 3> Ip1dxp2dz = p.I +   p.DI[0] + 2*p.DI[2];
    vect<int, 3> Ip1dxp1dz = p.I +   p.DI[0] +   p.DI[2];
    vect<int, 3> Ip1dxm3dz = p.I +   p.DI[0] - 3*p.DI[2];
    vect<int, 3> Ip1dxm2dz = p.I +   p.DI[0] - 2*p.DI[2];
    vect<int, 3> Ip1dxm1dz = p.I +   p.DI[0] -   p.DI[2];

    vect<int, 3> Im3dxp3dy = p.I - 3*p.DI[0] + 3*p.DI[1];
    vect<int, 3> Im3dxp2dy = p.I - 3*p.DI[0] + 2*p.DI[1];
    vect<int, 3> Im3dxp1dy = p.I - 3*p.DI[0] +   p.DI[1];
    vect<int, 3> Im3dxm3dy = p.I - 3*p.DI[0] - 3*p.DI[1];
    vect<int, 3> Im3dxm2dy = p.I - 3*p.DI[0] - 2*p.DI[1];
    vect<int, 3> Im3dxm1dy = p.I - 3*p.DI[0] -   p.DI[1];
    vect<int, 3> Im3dxp3dz = p.I - 3*p.DI[0] + 3*p.DI[2];
    vect<int, 3> Im3dxp2dz = p.I - 3*p.DI[0] + 2*p.DI[2];
    vect<int, 3> Im3dxp1dz = p.I - 3*p.DI[0] +   p.DI[2];
    vect<int, 3> Im3dxm3dz = p.I - 3*p.DI[0] - 3*p.DI[2];
    vect<int, 3> Im3dxm2dz = p.I - 3*p.DI[0] - 2*p.DI[2];
    vect<int, 3> Im3dxm1dz = p.I - 3*p.DI[0] -   p.DI[2];

    vect<int, 3> Im2dxp3dy = p.I - 2*p.DI[0] + 3*p.DI[1];
    vect<int, 3> Im2dxp2dy = p.I - 2*p.DI[0] + 2*p.DI[1];
    vect<int, 3> Im2dxp1dy = p.I - 2*p.DI[0] +   p.DI[1];
    vect<int, 3> Im2dxm3dy = p.I - 2*p.DI[0] - 3*p.DI[1];
    vect<int, 3> Im2dxm2dy = p.I - 2*p.DI[0] - 2*p.DI[1];
    vect<int, 3> Im2dxm1dy = p.I - 2*p.DI[0] -   p.DI[1];
    vect<int, 3> Im2dxp3dz = p.I - 2*p.DI[0] + 3*p.DI[2];
    vect<int, 3> Im2dxp2dz = p.I - 2*p.DI[0] + 2*p.DI[2];
    vect<int, 3> Im2dxp1dz = p.I - 2*p.DI[0] +   p.DI[2];
    vect<int, 3> Im2dxm3dz = p.I - 2*p.DI[0] - 3*p.DI[2];
    vect<int, 3> Im2dxm2dz = p.I - 2*p.DI[0] - 2*p.DI[2];
    vect<int, 3> Im2dxm1dz = p.I - 2*p.DI[0] -   p.DI[2];

    vect<int, 3> Im1dxp3dy = p.I -   p.DI[0] + 3*p.DI[1];
    vect<int, 3> Im1dxp2dy = p.I -   p.DI[0] + 2*p.DI[1];
    vect<int, 3> Im1dxp1dy = p.I -   p.DI[0] +   p.DI[1];
    vect<int, 3> Im1dxm3dy = p.I -   p.DI[0] - 3*p.DI[1];
    vect<int, 3> Im1dxm2dy = p.I -   p.DI[0] - 2*p.DI[1];
    vect<int, 3> Im1dxm1dy = p.I -   p.DI[0] -   p.DI[1];
    vect<int, 3> Im1dxp3dz = p.I -   p.DI[0] + 3*p.DI[2];
    vect<int, 3> Im1dxp2dz = p.I -   p.DI[0] + 2*p.DI[2];
    vect<int, 3> Im1dxp1dz = p.I -   p.DI[0] +   p.DI[2];
    vect<int, 3> Im1dxm3dz = p.I -   p.DI[0] - 3*p.DI[2];
    vect<int, 3> Im1dxm2dz = p.I -   p.DI[0] - 2*p.DI[2];
    vect<int, 3> Im1dxm1dz = p.I -   p.DI[0] -   p.DI[2];

    vect<int, 3> Ip3dyp3dz = p.I + 3*p.DI[1] + 3*p.DI[2];
    vect<int, 3> Ip3dyp2dz = p.I + 3*p.DI[1] + 2*p.DI[2];
    vect<int, 3> Ip3dyp1dz = p.I + 3*p.DI[1] +   p.DI[2];
    vect<int, 3> Ip3dym3dz = p.I + 3*p.DI[1] - 3*p.DI[2];
    vect<int, 3> Ip3dym2dz = p.I + 3*p.DI[1] - 2*p.DI[2];
    vect<int, 3> Ip3dym1dz = p.I + 3*p.DI[1] -   p.DI[2];

    vect<int, 3> Ip2dyp3dz = p.I + 2*p.DI[1] + 3*p.DI[2];
    vect<int, 3> Ip2dyp2dz = p.I + 2*p.DI[1] + 2*p.DI[2];
    vect<int, 3> Ip2dyp1dz = p.I + 2*p.DI[1] +   p.DI[2];
    vect<int, 3> Ip2dym3dz = p.I + 2*p.DI[1] - 3*p.DI[2];
    vect<int, 3> Ip2dym2dz = p.I + 2*p.DI[1] - 2*p.DI[2];
    vect<int, 3> Ip2dym1dz = p.I + 2*p.DI[1] -   p.DI[2];

    vect<int, 3> Ip1dyp3dz = p.I +   p.DI[1] + 3*p.DI[2];
    vect<int, 3> Ip1dyp2dz = p.I +   p.DI[1] + 2*p.DI[2];
    vect<int, 3> Ip1dyp1dz = p.I +   p.DI[1] +   p.DI[2];
    vect<int, 3> Ip1dym3dz = p.I +   p.DI[1] - 3*p.DI[2];
    vect<int, 3> Ip1dym2dz = p.I +   p.DI[1] - 2*p.DI[2];
    vect<int, 3> Ip1dym1dz = p.I +   p.DI[1] -   p.DI[2];

    vect<int, 3> Im3dyp3dz = p.I - 3*p.DI[1] + 3*p.DI[2];
    vect<int, 3> Im3dyp2dz = p.I - 3*p.DI[1] + 2*p.DI[2];
    vect<int, 3> Im3dyp1dz = p.I - 3*p.DI[1] +   p.DI[2];
    vect<int, 3> Im3dym3dz = p.I - 3*p.DI[1] - 3*p.DI[2];
    vect<int, 3> Im3dym2dz = p.I - 3*p.DI[1] - 2*p.DI[2];
    vect<int, 3> Im3dym1dz = p.I - 3*p.DI[1] -   p.DI[2];

    vect<int, 3> Im2dyp3dz = p.I - 2*p.DI[1] + 3*p.DI[2];
    vect<int, 3> Im2dyp2dz = p.I - 2*p.DI[1] + 2*p.DI[2];
    vect<int, 3> Im2dyp1dz = p.I - 2*p.DI[1] +   p.DI[2];
    vect<int, 3> Im2dym3dz = p.I - 2*p.DI[1] - 3*p.DI[2];
    vect<int, 3> Im2dym2dz = p.I - 2*p.DI[1] - 2*p.DI[2];
    vect<int, 3> Im2dym1dz = p.I - 2*p.DI[1] -   p.DI[2];

    vect<int, 3> Im1dyp3dz = p.I -   p.DI[1] + 3*p.DI[2];
    vect<int, 3> Im1dyp2dz = p.I -   p.DI[1] + 2*p.DI[2];
    vect<int, 3> Im1dyp1dz = p.I -   p.DI[1] +   p.DI[2];
    vect<int, 3> Im1dym3dz = p.I -   p.DI[1] - 3*p.DI[2];
    vect<int, 3> Im1dym2dz = p.I -   p.DI[1] - 2*p.DI[2];
    vect<int, 3> Im1dym1dz = p.I -   p.DI[1] -   p.DI[2];

    // 6th order coeffs
    CCTK_REAL inv60dx = 1.0/(60*p.DX[0]);
    CCTK_REAL inv60dy = 1.0/(60*p.DX[1]);
    CCTK_REAL inv60dz = 1.0/(60*p.DX[2]);
    CCTK_REAL inv180dxsq = 1.0/(180*p.DX[0]*p.DX[0]);
    CCTK_REAL inv180dysq = 1.0/(180*p.DX[1]*p.DX[1]);
    CCTK_REAL inv180dzsq = 1.0/(180*p.DX[2]*p.DX[2]);
    CCTK_REAL inv3600dxdy = 1.0/(3600 * p.DX[0] * p.DX[1]);
    CCTK_REAL inv3600dxdz = 1.0/(3600 * p.DX[0] * p.DX[2]);
    CCTK_REAL inv3600dydz = 1.0/(3600 * p.DX[1] * p.DX[2]);
    // 4th order coeffs
    CCTK_REAL inv12dx = 1.0/(12*p.DX[0]);
    CCTK_REAL inv12dy = 1.0/(12*p.DX[1]);
    CCTK_REAL inv12dz = 1.0/(12*p.DX[2]);
    CCTK_REAL inv12dxsq = 1.0/(12*p.DX[0]*p.DX[0]);
    CCTK_REAL inv12dysq = 1.0/(12*p.DX[1]*p.DX[1]);
    CCTK_REAL inv12dzsq = 1.0/(12*p.DX[2]*p.DX[2]);
    CCTK_REAL inv144dxdy = 1.0/(144 * p.DX[0] * p.DX[1]);
    CCTK_REAL inv144dxdz = 1.0/(144 * p.DX[0] * p.DX[2]);
    CCTK_REAL inv144dydz = 1.0/(144 * p.DX[1] * p.DX[2]);


    //------------ Invert metric ----------------
    //invert_metric(hhUU, hhDD);
    dethh =     hhDD[0][0] * hhDD[1][1] * hhDD[2][2]
          + 2 * hhDD[0][1] * hhDD[0][2] * hhDD[1][2]
          -     hhDD[0][0] * hhDD[1][2] * hhDD[1][2]
          -     hhDD[1][1] * hhDD[0][2] * hhDD[0][2]
          -     hhDD[2][2] * hhDD[0][1] * hhDD[0][1];

    hhUU[0][0] = (hhDD[1][1] * hhDD[2][2] - hhDD[1][2] * hhDD[1][2]) / dethh;
    hhUU[1][1] = (hhDD[0][0] * hhDD[2][2] - hhDD[0][2] * hhDD[0][2]) / dethh;
    hhUU[2][2] = (hhDD[0][0] * hhDD[1][1] - hhDD[0][1] * hhDD[0][1]) / dethh;
    hhUU[0][1] = (hhDD[0][2] * hhDD[1][2] - hhDD[0][1] * hhDD[2][2]) / dethh;
    hhUU[0][2] = (hhDD[0][1] * hhDD[1][2] - hhDD[0][2] * hhDD[1][1]) / dethh;
    hhUU[1][2] = (hhDD[0][2] * hhDD[0][1] - hhDD[1][2] * hhDD[0][0]) / dethh;
    hhUU[1][0] = hhUU[0][1];
    hhUU[2][0] = hhUU[0][2];
    hhUU[2][1] = hhUU[1][2];



    // Evaluate derivatives
    // FD order = 6
    if(FD_order == 6){
      /*----------------------*/
      /* ----- first derivative ------- */
      /*----------------------*/
      //----------------------
      //d1_ww
      //--------
      d1_ww[0] = FD_DX_VI(conf_fac);
      //-------
      d1_ww[1] = FD_DY_VI(conf_fac);
      //------
      d1_ww[2] = FD_DZ_VI(conf_fac);
      //----------------------
      //d1_hhDD
      //------
      d1_hh11[0] = FD_DX_VI(hxx);
      d1_hh12[0] = FD_DX_VI(hxy);
      d1_hh13[0] = FD_DX_VI(hxz);
      d1_hh22[0] = FD_DX_VI(hyy);
      d1_hh23[0] = FD_DX_VI(hyz);
      d1_hh33[0] = FD_DX_VI(hzz);
      //---------
      d1_hh11[1] = FD_DY_VI(hxx);
      d1_hh12[1] = FD_DY_VI(hxy);
      d1_hh13[1] = FD_DY_VI(hxz);
      d1_hh22[1] = FD_DY_VI(hyy);
      d1_hh23[1] = FD_DY_VI(hyz);
      d1_hh33[1] = FD_DY_VI(hzz);
      //--------
      d1_hh11[2] = FD_DZ_VI(hxx);
      d1_hh12[2] = FD_DZ_VI(hxy);
      d1_hh13[2] = FD_DZ_VI(hxz);
      d1_hh22[2] = FD_DZ_VI(hyy);
      d1_hh23[2] = FD_DZ_VI(hyz);
      d1_hh33[2] = FD_DZ_VI(hzz);
      //----------------------
      //d1_trk
      //------
      d1_trk[0] = FD_DX_VI(tracek);
      //-------
      d1_trk[1] = FD_DY_VI(tracek);
      //------
      d1_trk[2] = FD_DZ_VI(tracek);
      //----------------------
      //d1_aaDD
      //------
      d1_aa11[0] = FD_DX_VI(axx);
      d1_aa12[0] = FD_DX_VI(axy);
      d1_aa13[0] = FD_DX_VI(axz);
      d1_aa22[0] = FD_DX_VI(ayy);
      d1_aa23[0] = FD_DX_VI(ayz);
      d1_aa33[0] = FD_DX_VI(azz);
      //---------
      d1_aa11[1] = FD_DY_VI(axx);
      d1_aa12[1] = FD_DY_VI(axy);
      d1_aa13[1] = FD_DY_VI(axz);
      d1_aa22[1] = FD_DY_VI(ayy);
      d1_aa23[1] = FD_DY_VI(ayz);
      d1_aa33[1] = FD_DY_VI(azz);
      //--------
      d1_aa11[2] = FD_DZ_VI(axx);
      d1_aa12[2] = FD_DZ_VI(axy);
      d1_aa13[2] = FD_DZ_VI(axz);
      d1_aa22[2] = FD_DZ_VI(ayy);
      d1_aa23[2] = FD_DZ_VI(ayz);
      d1_aa33[2] = FD_DZ_VI(azz);
      //-------------------------------------------
      //d1_gammatU
      //------
      d1_gammat1[0] = FD_DX_VI(gammatx);
      d1_gammat2[0] = FD_DX_VI(gammaty);
      d1_gammat3[0] = FD_DX_VI(gammatz);
      //---------
      d1_gammat1[1] = FD_DY_VI(gammatx);
      d1_gammat2[1] = FD_DY_VI(gammaty);
      d1_gammat3[1] = FD_DY_VI(gammatz);
      //--------
      d1_gammat1[2] = FD_DZ_VI(gammatx);
      d1_gammat2[2] = FD_DZ_VI(gammaty);
      d1_gammat3[2] = FD_DZ_VI(gammatz);

      //------------------------------------------
      // ------ second order derivatives ---------
      //------------------------------------------

      //-----------------------------------------
      //d2_ww
      //-----------
      d2_ww[0][0] = FD_DXDX_VI(conf_fac);
      //-------
      d2_ww[1][1] = FD_DYDY_VI(conf_fac);
      //------
      d2_ww[2][2] = FD_DZDZ_VI(conf_fac);
      //-----------------------------------------
      //d2_hhDD
      //-----------
      d2_hh11[0][0] = FD_DXDX_VI(hxx);
      d2_hh12[0][0] = FD_DXDX_VI(hxy);
      d2_hh13[0][0] = FD_DXDX_VI(hxz);
      d2_hh22[0][0] = FD_DXDX_VI(hyy);
      d2_hh23[0][0] = FD_DXDX_VI(hyz);
      d2_hh33[0][0] = FD_DXDX_VI(hzz);
      //---------
      d2_hh11[1][1] = FD_DYDY_VI(hxx);
      d2_hh12[1][1] = FD_DYDY_VI(hxy);
      d2_hh13[1][1] = FD_DYDY_VI(hxz);
      d2_hh22[1][1] = FD_DYDY_VI(hyy);
      d2_hh23[1][1] = FD_DYDY_VI(hyz);
      d2_hh33[1][1] = FD_DYDY_VI(hzz);
      //--------
      d2_hh11[2][2] = FD_DZDZ_VI(hxx);
      d2_hh12[2][2] = FD_DZDZ_VI(hxy);
      d2_hh13[2][2] = FD_DZDZ_VI(hxz);
      d2_hh22[2][2] = FD_DZDZ_VI(hyy);
      d2_hh23[2][2] = FD_DZDZ_VI(hyz);
      d2_hh33[2][2] = FD_DZDZ_VI(hzz);
      // -------------------------------------------------------------------------------
      // d2_ww_IJ
      // --------
      d2_ww[0][1] = FD_DXDY_VI(conf_fac);
      //--------------
      d2_ww[0][2] = FD_DXDZ_VI(conf_fac);
      //--------------
      d2_ww[1][2] = FD_DYDZ_VI(conf_fac);
      //--------------
      d2_ww[1][0] = d2_ww[0][1] ;
      d2_ww[2][0] = d2_ww[0][2] ;
      d2_ww[2][1] = d2_ww[1][2] ;

      // ---------------------------------------------------------------------------------
      // d2_hhDD_IJ
      //-----------
      d2_hh11[0][1] = FD_DXDY_VI(hxx);
      d2_hh12[0][1] = FD_DXDY_VI(hxy);
      d2_hh13[0][1] = FD_DXDY_VI(hxz);
      d2_hh22[0][1] = FD_DXDY_VI(hyy);
      d2_hh23[0][1] = FD_DXDY_VI(hyz);
      d2_hh33[0][1] = FD_DXDY_VI(hzz);
      //-----------
      d2_hh11[0][2] = FD_DXDZ_VI(hxx);
      d2_hh12[0][2] = FD_DXDZ_VI(hxy);
      d2_hh13[0][2] = FD_DXDZ_VI(hxz);
      d2_hh22[0][2] = FD_DXDZ_VI(hyy);
      d2_hh23[0][2] = FD_DXDZ_VI(hyz);
      d2_hh33[0][2] = FD_DXDZ_VI(hzz);
      //-----------
      d2_hh11[1][2] = FD_DYDZ_VI(hxx);
      d2_hh12[1][2] = FD_DYDZ_VI(hxy);
      d2_hh13[1][2] = FD_DYDZ_VI(hxz);
      d2_hh22[1][2] = FD_DYDZ_VI(hyy);
      d2_hh23[1][2] = FD_DYDZ_VI(hyz);
      d2_hh33[1][2] = FD_DYDZ_VI(hzz);
      //-----------
      d2_hh11[1][0] = d2_hh11[0][1];
      d2_hh12[1][0] = d2_hh12[0][1];
      d2_hh13[1][0] = d2_hh13[0][1];
      d2_hh22[1][0] = d2_hh22[0][1];
      d2_hh23[1][0] = d2_hh23[0][1];
      d2_hh33[1][0] = d2_hh33[0][1];
      d2_hh11[2][0] = d2_hh11[0][2];
      d2_hh12[2][0] = d2_hh12[0][2];
      d2_hh13[2][0] = d2_hh13[0][2];
      d2_hh22[2][0] = d2_hh22[0][2];
      d2_hh23[2][0] = d2_hh23[0][2];
      d2_hh33[2][0] = d2_hh33[0][2];
      d2_hh11[2][1] = d2_hh11[1][2];
      d2_hh12[2][1] = d2_hh12[1][2];
      d2_hh13[2][1] = d2_hh13[1][2];
      d2_hh22[2][1] = d2_hh22[1][2];
      d2_hh23[2][1] = d2_hh23[1][2];
      d2_hh33[2][1] = d2_hh33[1][2];
    } // if (FD_order == 6)
    // FD order = 4
    else if(FD_order == 4){
      //loop over spatial indices
      /* ----- first derivative ------- */
      /*----------------------*/
      //----------------------
      //d1_ww
      //--------
      d1_ww[0] = FD_DX_IV(conf_fac);
      //-------
      d1_ww[1] = FD_DY_IV(conf_fac);
      //------
      d1_ww[2] = FD_DZ_IV(conf_fac);
      //----------------------
      //d1_hhDD
      //------
      d1_hh11[0] = FD_DX_IV(hxx);
      d1_hh12[0] = FD_DX_IV(hxy);
      d1_hh13[0] = FD_DX_IV(hxz);
      d1_hh22[0] = FD_DX_IV(hyy);
      d1_hh23[0] = FD_DX_IV(hyz);
      d1_hh33[0] = FD_DX_IV(hzz);
      //---------
      d1_hh11[1] = FD_DY_IV(hxx);
      d1_hh12[1] = FD_DY_IV(hxy);
      d1_hh13[1] = FD_DY_IV(hxz);
      d1_hh22[1] = FD_DY_IV(hyy);
      d1_hh23[1] = FD_DY_IV(hyz);
      d1_hh33[1] = FD_DY_IV(hzz);
      //--------
      d1_hh11[2] = FD_DZ_IV(hxx);
      d1_hh12[2] = FD_DZ_IV(hxy);
      d1_hh13[2] = FD_DZ_IV(hxz);
      d1_hh22[2] = FD_DZ_IV(hyy);
      d1_hh23[2] = FD_DZ_IV(hyz);
      d1_hh33[2] = FD_DZ_IV(hzz);
      //----------------------
      //d1_trk
      //------
      d1_trk[0] = FD_DX_IV(tracek);
      //-------
      d1_trk[1] = FD_DY_IV(tracek);
      //------
      d1_trk[2] = FD_DZ_IV(tracek);
      //----------------------
      //d1_aaDD
      //------
      d1_aa11[0] = FD_DX_IV(axx);
      d1_aa12[0] = FD_DX_IV(axy);
      d1_aa13[0] = FD_DX_IV(axz);
      d1_aa22[0] = FD_DX_IV(ayy);
      d1_aa23[0] = FD_DX_IV(ayz);
      d1_aa33[0] = FD_DX_IV(azz);
      //---------
      d1_aa11[1] = FD_DY_IV(axx);
      d1_aa12[1] = FD_DY_IV(axy);
      d1_aa13[1] = FD_DY_IV(axz);
      d1_aa22[1] = FD_DY_IV(ayy);
      d1_aa23[1] = FD_DY_IV(ayz);
      d1_aa33[1] = FD_DY_IV(azz);
      //--------
      d1_aa11[2] = FD_DZ_IV(axx);
      d1_aa12[2] = FD_DZ_IV(axy);
      d1_aa13[2] = FD_DZ_IV(axz);
      d1_aa22[2] = FD_DZ_IV(ayy);
      d1_aa23[2] = FD_DZ_IV(ayz);
      d1_aa33[2] = FD_DZ_IV(azz);
      //-------------------------------------------
      //d1_gammatU
      //------
      d1_gammat1[0] = FD_DX_IV(gammatx);
      d1_gammat2[0] = FD_DX_IV(gammaty);
      d1_gammat3[0] = FD_DX_IV(gammatz);
      //---------
      d1_gammat1[1] = FD_DY_IV(gammatx);
      d1_gammat2[1] = FD_DY_IV(gammaty);
      d1_gammat3[1] = FD_DY_IV(gammatz);
      //--------
      d1_gammat1[2] = FD_DZ_IV(gammatx);
      d1_gammat2[2] = FD_DZ_IV(gammaty);
      d1_gammat3[2] = FD_DZ_IV(gammatz);

      //------------------------------------------
      // ------ second order derivatives ---------
      //------------------------------------------

      //-----------------------------------------
      //d2_ww
      //-----------
      d2_ww[0][0] = FD_DXDX_IV(conf_fac);
      //-------
      d2_ww[1][1] = FD_DYDY_IV(conf_fac);
      //------
      d2_ww[2][2] = FD_DZDZ_IV(conf_fac);
      //-----------------------------------------
      //d2_hhDD
      //-----------
      d2_hh11[0][0] = FD_DXDX_IV(hxx);
      d2_hh12[0][0] = FD_DXDX_IV(hxy);
      d2_hh13[0][0] = FD_DXDX_IV(hxz);
      d2_hh22[0][0] = FD_DXDX_IV(hyy);
      d2_hh23[0][0] = FD_DXDX_IV(hyz);
      d2_hh33[0][0] = FD_DXDX_IV(hzz);
      //---------
      d2_hh11[1][1] = FD_DYDY_IV(hxx);
      d2_hh12[1][1] = FD_DYDY_IV(hxy);
      d2_hh13[1][1] = FD_DYDY_IV(hxz);
      d2_hh22[1][1] = FD_DYDY_IV(hyy);
      d2_hh23[1][1] = FD_DYDY_IV(hyz);
      d2_hh33[1][1] = FD_DYDY_IV(hzz);
      //--------
      d2_hh11[2][2] = FD_DZDZ_IV(hxx);
      d2_hh12[2][2] = FD_DZDZ_IV(hxy);
      d2_hh13[2][2] = FD_DZDZ_IV(hxz);
      d2_hh22[2][2] = FD_DZDZ_IV(hyy);
      d2_hh23[2][2] = FD_DZDZ_IV(hyz);
      d2_hh33[2][2] = FD_DZDZ_IV(hzz);
      // -------------------------------------------------------------------------------
      // d2_ww_IJ
      // --------
      d2_ww[0][1] = FD_DXDY_IV(conf_fac);
      //--------------
      d2_ww[0][2] = FD_DXDZ_IV(conf_fac);
      //--------------
      d2_ww[1][2] = FD_DYDZ_IV(conf_fac);
      //--------------
      d2_ww[1][0] = d2_ww[0][1] ;
      d2_ww[2][0] = d2_ww[0][2] ;
      d2_ww[2][1] = d2_ww[1][2] ;

      // ---------------------------------------------------------------------------------
      // d2_hhDD_IJ
      //-----------
      d2_hh11[0][1] = FD_DXDY_IV(hxx);
      d2_hh12[0][1] = FD_DXDY_IV(hxy);
      d2_hh13[0][1] = FD_DXDY_IV(hxz);
      d2_hh22[0][1] = FD_DXDY_IV(hyy);
      d2_hh23[0][1] = FD_DXDY_IV(hyz);
      d2_hh33[0][1] = FD_DXDY_IV(hzz);
      //-----------
      d2_hh11[0][2] = FD_DXDZ_IV(hxx);
      d2_hh12[0][2] = FD_DXDZ_IV(hxy);
      d2_hh13[0][2] = FD_DXDZ_IV(hxz);
      d2_hh22[0][2] = FD_DXDZ_IV(hyy);
      d2_hh23[0][2] = FD_DXDZ_IV(hyz);
      d2_hh33[0][2] = FD_DXDZ_IV(hzz);
      //-----------
      d2_hh11[1][2] = FD_DYDZ_IV(hxx);
      d2_hh12[1][2] = FD_DYDZ_IV(hxy);
      d2_hh13[1][2] = FD_DYDZ_IV(hxz);
      d2_hh22[1][2] = FD_DYDZ_IV(hyy);
      d2_hh23[1][2] = FD_DYDZ_IV(hyz);
      d2_hh33[1][2] = FD_DYDZ_IV(hzz);
      //-----------
      d2_hh11[1][0] = d2_hh11[0][1];
      d2_hh12[1][0] = d2_hh12[0][1];
      d2_hh13[1][0] = d2_hh13[0][1];
      d2_hh22[1][0] = d2_hh22[0][1];
      d2_hh23[1][0] = d2_hh23[0][1];
      d2_hh33[1][0] = d2_hh33[0][1];
      d2_hh11[2][0] = d2_hh11[0][2];
      d2_hh12[2][0] = d2_hh12[0][2];
      d2_hh13[2][0] = d2_hh13[0][2];
      d2_hh22[2][0] = d2_hh22[0][2];
      d2_hh23[2][0] = d2_hh23[0][2];
      d2_hh33[2][0] = d2_hh33[0][2];
      d2_hh11[2][1] = d2_hh11[1][2];
      d2_hh12[2][1] = d2_hh12[1][2];
      d2_hh13[2][1] = d2_hh13[1][2];
      d2_hh22[2][1] = d2_hh22[1][2];
      d2_hh23[2][1] = d2_hh23[1][2];
      d2_hh33[2][1] = d2_hh33[1][2];
    } // if (FD_order == 4)
    else{
      // CCTK_ERROR("Please select a valid FD order!");
      assert(0);
    }

    // fill remaining derivative matrices
    for(i=0; i<3; i++){

      d1_gammatU[0][i] = d1_gammat1[i];
      d1_gammatU[1][i] = d1_gammat2[i];
      d1_gammatU[2][i] = d1_gammat3[i];

      d1_hhDD[0][0][i] = d1_hh11[i];
      d1_hhDD[0][1][i] = d1_hh12[i];
      d1_hhDD[0][2][i] = d1_hh13[i];
      d1_hhDD[1][1][i] = d1_hh22[i];
      d1_hhDD[1][2][i] = d1_hh23[i];
      d1_hhDD[2][2][i] = d1_hh33[i];
      d1_hhDD[1][0][i] = d1_hhDD[0][1][i];
      d1_hhDD[2][0][i] = d1_hhDD[0][2][i];
      d1_hhDD[2][1][i] = d1_hhDD[1][2][i];

      d1_aaDD[0][0][i] = d1_aa11[i];
      d1_aaDD[0][1][i] = d1_aa12[i];
      d1_aaDD[0][2][i] = d1_aa13[i];
      d1_aaDD[1][1][i] = d1_aa22[i];
      d1_aaDD[1][2][i] = d1_aa23[i];
      d1_aaDD[2][2][i] = d1_aa33[i];
      d1_aaDD[1][0][i] = d1_aaDD[0][1][i];
      d1_aaDD[2][0][i] = d1_aaDD[0][2][i];
      d1_aaDD[2][1][i] = d1_aaDD[1][2][i];

      for(j=0; j<3; j++){

        d2_hhDD[0][0][i][j] = d2_hh11[i][j];
        d2_hhDD[0][1][i][j] = d2_hh12[i][j];
        d2_hhDD[0][2][i][j] = d2_hh13[i][j];
        d2_hhDD[1][1][i][j] = d2_hh22[i][j];
        d2_hhDD[1][2][i][j] = d2_hh23[i][j];
        d2_hhDD[2][2][i][j] = d2_hh33[i][j];
        d2_hhDD[1][0][i][j] = d2_hh12[i][j];
        d2_hhDD[2][0][i][j] = d2_hh13[i][j];
        d2_hhDD[2][1][i][j] = d2_hh23[i][j];
      }
    }

    //------------ Christoffel symbols ----------
    for(a=0; a<3; a++) {
      for(b=0; b<3; b++) {
        for(c=0; c<3; c++) {
          cf1[a][b][c] = 0.5 * (d1_hhDD[a][b][c] + d1_hhDD[a][c][b] - d1_hhDD[b][c][a]);
        }
      }
    }

    for(a=0; a<3; a++) {
      for(b=0; b<3; b++) {
        for(c=0; c<3; c++) {
          cf2[a][b][c] = 0.;
          for(d=0; d<3; d++) {
            cf2[a][b][c] += hhUU[a][d] * cf1[d][b][c];
          }
        }
      }
    }

    //-------------------------------------------


    //------------ Covariant derivatives --------
    for(a=0; a<3; a++) {
      for(b=a; b<3; b++) {
        cd2_ww[a][b]    = d2_ww[a][b];
        cd1_aaDD[a][b][0] = d1_aaDD[a][b][0];
        cd1_aaDD[a][b][1] = d1_aaDD[a][b][1];
        cd1_aaDD[a][b][2] = d1_aaDD[a][b][2];
        for(c=0; c<3; c++) {
          cd2_ww[a][b] -= cf2[c][a][b] * d1_ww[c];
          for(d=0; d<3; d++) {
            cd1_aaDD[a][b][c] += - cf2[d][a][c] * aaDD[b][d]
                               - cf2[d][b][c] * aaDD[a][d];
          }
        }
      }
    }
    cd2_ww[1][0] = cd2_ww[0][1];
    cd2_ww[2][0] = cd2_ww[0][2];
    cd2_ww[2][1] = cd2_ww[1][2];

    for (a=0; a<3; a++) {
      cd1_aaDD[1][0][a] = cd1_aaDD[0][1][a];
      cd1_aaDD[2][0][a] = cd1_aaDD[0][2][a];
      cd1_aaDD[2][1][a] = cd1_aaDD[1][2][a];
    }
    //-------------------------------------------


    //------------ Ricci Tensor -----------------
    // Note: we are implementing W^2 R_{ij} here
    for (a=0; a<3; a++) {
      for (b=0; b<3; b++) {
        ri_1[a][b] = 0;
        ri_2[a][b] = 0;
        ri_3[a][b] = 0;
        c_ri_ww[a][b] = 0;
        c_ri_hh[a][b] = 0;
      }
    }

    tr_cd2_ww   = 0;
    tr_dww_dww  = 0;
    for (l=0; l<3; l++) {
      for (m=0; m<3; m++) {
          tr_cd2_ww  += hhUU[l][m] * cd2_ww[l][m];
          tr_dww_dww += hhUU[l][m] * d1_ww[l] * d1_ww[m];
      }
    }

    // Note: we are implementing W^2 R_{ij} here
    for (a=0; a<3; a++) {
      for (b=0; b<3; b++) {
        c_ri_ww[a][b] = ww * ( cd2_ww[a][b] + hhDD[a][b] * tr_cd2_ww )
                      - hhDD[a][b] * tr_dww_dww * 2;
      }
    }

    for (a=0; a<3; a++) {
      for (b=a; b<3; b++) {
        for (l=0; l<3; l++) {
          ri_1[a][b] +=   hhDD[l][a] * d1_gammatU[l][b] / 2
                        + hhDD[l][b] * d1_gammatU[l][a] / 2
                        + gammatU[l] * (cf1[a][b][l] + cf1[b][a][l]) / 2;

          for (m=0; m<3; m++) {
            ri_2[a][b] -= hhUU[l][m] * d2_hhDD[a][b][l][m] / 2;

            for (n=0; n<3; n++) {
              ri_3[a][b] += hhUU[l][m] * (  cf2[n][l][a] * cf1[b][n][m]
                                         +  cf2[n][l][b] * cf1[a][n][m]
                                         +  cf2[n][l][b] * cf1[n][m][a] );
            }
          }
        }
      }
    }

    // Note: we are implementing W^2 R_{ij} here
    for (a=0; a<3; a++) {
      for (b=a; b<3; b++) {
        c_ri_hh[a][b] = ww*ww * (ri_1[a][b] + ri_2[a][b] + ri_3[a][b]);
        c_ri[a][b]      = c_ri_ww[a][b] + c_ri_hh[a][b];
      }
    }
    c_ri[1][0] = c_ri[0][1];
    c_ri[2][0] = c_ri[0][2];
    c_ri[2][1] = c_ri[1][2];

    trr = 0;
    for (m=0; m<3; m++) {
      for (n=0; n<3; n++) {
        trr += hhUU[m][n] * c_ri[m][n];
      }
    }
    //-------------------------------------------


    //------------ Source terms -----------------
    sq_aa = 0;
    for (a=0; a<3; a++) {
      for (b=0; b<3; b++) {
          aaDU_aaDD[a][b] = 0;
      }
    }

    for (m=0; m<3; m++) {
      for (n=0; n<3; n++) {
        for (a=0; a<3; a++) {
          for (b=0; b<3; b++) {
            aaDU_aaDD[m][n] += hhUU[a][b] * aaDD[m][a] * aaDD[n][b];
          }
        }
        sq_aa += hhUU[m][n] * aaDU_aaDD[m][n];
      }
    }
    //-------------------------------------------


    //------------ Constraints ------------------
    ham = trr + 2 * trk*trk / 3 - sq_aa;
    //ham = 0;

    for (a=0; a<3; a++) {
      mom[a] = -2 * d1_trk[a] / 3;
      for (l=0; l<3; l++) {
        for (m=0; m<3; m++) {
          mom[a] += hhUU[l][m] * ( cd1_aaDD[a][l][m] - 3 * aaDD[a][l] * d1_ww[m] / ww );
        }
      }
    }
    //-------------------------------------------


    //------------ Matter terms -----------------
    // n_mu = (-alph, 0, 0, 0)
    // n^mu = (1, -betax, -betay, -betaz)/alph
    //
    // E   = n^mu n^nu T_{mu nu}
    //     = (T_{00} - 2 beta^i T_{i0} + beta^i beta^j T_{ij})/alph^2
    //
    // j_a = -h_a^mu n^nu T_{mu nu}
    //     = -(T_{a 0} - beta^j T_{a j})/alph
    // stress-energy tensor variables
    if (stress_energy_state) {

      Tab[3][3] = eTtt(p.I);
      Tab[3][0] = eTtx(p.I);
      Tab[3][1] = eTty(p.I);
      Tab[3][2] = eTtz(p.I);
      Tab[0][0] = eTxx(p.I);
      Tab[0][1] = eTxy(p.I);
      Tab[0][2] = eTxz(p.I);
      Tab[1][1] = eTyy(p.I);
      Tab[1][2] = eTyz(p.I);
      Tab[2][2] = eTzz(p.I);
      Tab[0][3] = Tab[3][0];
      Tab[1][3] = Tab[3][1];
      Tab[2][3] = Tab[3][2];
      Tab[1][0] = Tab[0][1];
      Tab[2][0] = Tab[0][2];
      Tab[2][1] = Tab[1][2];


      srcE = Tab[3][3];
      srcjdi[0] = 0;
      srcjdi[1] = 0;
      srcjdi[2] = 0;

      for (m=0; m<3; m++) {

        srcjdi[0]   += betaU[m] * Tab[0][m];
        srcjdi[1]   += betaU[m] * Tab[1][m];
        srcjdi[2]   += betaU[m] * Tab[2][m];
        srcE        -= betaU[m] * Tab[3][m] * 2;

        for (n=0; n<3; n++) {
          srcE        += betaU[m] * betaU[n] * Tab[m][n];
        }

      }

      srcE = srcE / (alph * alph);
      srcjdi[0] = (srcjdi[0] - Tab[0][3] - Tab[1][3] - Tab[2][3]) / alph;
      srcjdi[1] = (srcjdi[1] - Tab[0][3] - Tab[1][3] - Tab[2][3]) / alph;
      srcjdi[2] = (srcjdi[2] - Tab[0][3] - Tab[1][3] - Tab[2][3]) / alph;


      //------------ Correct source terms ---------
      ham    -= pi16 * srcE;
      mom[0] -= pi8  * srcjdi[0];
      mom[1] -= pi8  * srcjdi[1];
      mom[2] -= pi8  * srcjdi[2];

    } // if (stress_energy_state)


    //------------ Write to grid functions ------
    hc(p.I)  = ham;

    mcx(p.I) = mom[0];
    mcy(p.I) = mom[1];
    mcz(p.I) = mom[2];
    //-------------------------------------------

  });

}

extern "C" void LeanBSSN_bssn_constraints(CCTK_ARGUMENTS){    //scheduled bssn_constraints routine

  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_bssn_constraints;
  DECLARE_CCTK_PARAMETERS;

  switch (derivs_order){
    case 4:
      LeanBSSN_bssn_constraints_body<4>(CCTK_PASS_CTOC);
      break;
    case 6:
      LeanBSSN_bssn_constraints_body<6>(CCTK_PASS_CTOC);
      break;
    default:
      CCTK_ERROR("Invalid FD approximation order!");
  }
}

