// add_dissipation: add KO dissipation to rhs
//=============================================================================
#include <iostream>
#include <cmath>
#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "loop_device.hxx"
#include "evolve_utils.hxx"

// 9th order KO dissipation
#define KO_DISS_IX(gf)                                                                       \
  1.0 / 1024.0  *                                                                               \
  ( ( +         gf(im5jz) - 10.0 * gf(im4jz) + 45.0 * gf(im3jz) - 120.0 * gf(im2jz) + 210.0 * gf(im1jz) \
      - 252.0 * gf(ijz)                                                                                 \
      +         gf(ip5jz) - 10.0 * gf(ip4jz) + 45.0 * gf(ip3jz) - 120.0 * gf(ip2jz) + 210.0 * gf(ip1jz) \
    ) / p.DX[0]                                                                                         \
    +                                                                                                   \
    ( +         gf(ijm5z) - 10.0 * gf(ijm4z) + 45.0 * gf(ijm3z) - 120.0 * gf(ijm2z) + 210.0 * gf(ijm1z) \
      - 252.0 * gf(ijz)                                                                                 \
      +         gf(ijp5z) - 10.0 * gf(ijp4z) + 45.0 * gf(ijp3z) - 120.0 * gf(ijp2z) + 210.0 * gf(ijp1z) \
    ) / p.DX[1]                                                                                         \
    +                                                                                                   \
    ( +         gf(ijzm5) - 10.0 * gf(ijzm4) + 45.0 * gf(ijzm3) - 120.0 * gf(ijzm2) + 210.0 * gf(ijzm1) \
      - 252.0 * gf(ijz)                                                                                 \
      +         gf(ijzp5) - 10.0 * gf(ijzp4) + 45.0 * gf(ijzp3) - 120.0 * gf(ijzp2) + 210.0 * gf(ijzp1) \
    ) / p.DX[2] )
// 7th order KO dissipation
#define KO_DISS_VII(gf)                                                \
  - 1.0 / 256.0  * (                                                      \
    ( +        gf(im4jz) - 8.0 * gf(im3jz) + 28.0 * gf(im2jz) - 56.0 * gf(im1jz)  \
      + 70.0 * gf(ijz)                                                            \
      +        gf(ip4jz) - 8.0 * gf(ip3jz) + 28.0 * gf(ip2jz) - 56.0 * gf(ip1jz)  \
    ) / p.DX[0]                                                                   \
    +                                                                             \
    ( +        gf(ijm4z) - 8.0 * gf(ijm3z) + 28.0 * gf(ijm2z) - 56.0 * gf(ijm1z)  \
      + 70.0 * gf(ijz)                                                            \
      +        gf(ijp4z) - 8.0 * gf(ijp3z) + 28.0 * gf(ijp2z) - 56.0 * gf(ijp1z)  \
    ) / p.DX[1]                                                                   \
    +                                                                             \
    ( +        gf(ijzm4) - 8.0 * gf(ijzm3) + 28.0 * gf(ijzm2) - 56.0 * gf(ijzm1)  \
      + 70.0 * gf(ijz)                                                            \
      +        gf(ijzp4) - 8.0 * gf(ijzp3) + 28.0 * gf(ijzp2) - 56.0 * gf(ijzp1)  \
    ) / p.DX[2] )
// 5th order KO dissipation
#define KO_DISS_V(gf)                                                \
  1.0 / 64.0  * (                                                                                                          \
  + ( gf(im3jz) - 6.0 * gf(im2jz) + 15.0 * gf(im1jz) - 20.0 * gf(ijz) + 15.0 * gf(ip1jz) - 6.0 * gf(ip2jz) + gf(ip3jz) ) / p.DX[0] \
  + ( gf(ijm3z) - 6.0 * gf(ijm2z) + 15.0 * gf(ijm1z) - 20.0 * gf(ijz) + 15.0 * gf(ijp1z) - 6.0 * gf(ijp2z) + gf(ijp3z) ) / p.DX[1] \
  + ( gf(ijzm3) - 6.0 * gf(ijzm2) + 15.0 * gf(ijzm1) - 20.0 * gf(ijz) + 15.0 * gf(ijzp1) - 6.0 * gf(ijzp2) + gf(ijzp3) ) / p.DX[2] \
  )

using namespace CanudaX_BSSNMoL;
using namespace Loop;
using namespace std;

namespace CanudaX_BSSNMoL{
}

template <typename T> int sgn(T val) {
    return (T(0) < val) - (val < T(0));
}

template <int KO_order> void LeanBSSN_add_dissipation_body(CCTK_ARGUMENTS)
{

  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_add_dissipation;
  DECLARE_CCTK_PARAMETERS;

  //const int KO_order = 5;

  //---------------------------------------------------------------------------------------------
  //Loop over grid (interior)
  grid.loop_int_device<0,0,0>(
    grid.nghostzones,
    [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
        CCTK_ATTRIBUTE_ALWAYS_INLINE {

        //constexpr auto DI = PointDesc::DI;

        //define local copies of rhs variables
        CCTK_REAL diss_alpha;
        CCTK_REAL diss_beta1, diss_beta2, diss_beta3;
        CCTK_REAL diss_ww;
        CCTK_REAL diss_hh11, diss_hh12, diss_hh13, diss_hh22, diss_hh23, diss_hh33;
        CCTK_REAL diss_trk;
        CCTK_REAL diss_aa11, diss_aa12, diss_aa13, diss_aa22, diss_aa23, diss_aa33;
        CCTK_REAL diss_gammat1, diss_gammat2, diss_gammat3;

        CCTK_REAL diss_alpha0, diss_beta0, diss_ww0, diss_hhDD0;
        CCTK_REAL diss_trk0, diss_aaDD0, diss_gammat0;

        diss_alpha0   = diss_eps;
        diss_beta0    = diss_eps;
        diss_ww0      = diss_eps;
        diss_hhDD0    = diss_eps;
        diss_trk0     = diss_eps;
        diss_aaDD0    = diss_eps;
        diss_gammat0  = diss_eps;

        const auto ijz   = p.I;
        const auto im5jz = p.I - 5 * p.DI[0];
        const auto im4jz = p.I - 4 * p.DI[0];
        const auto im3jz = p.I - 3 * p.DI[0];
        const auto im2jz = p.I - 2 * p.DI[0];
        const auto im1jz = p.I - 1 * p.DI[0];
        const auto ip5jz = p.I + 5 * p.DI[0];
        const auto ip4jz = p.I + 4 * p.DI[0];
        const auto ip3jz = p.I + 3 * p.DI[0];
        const auto ip2jz = p.I + 2 * p.DI[0];
        const auto ip1jz = p.I + 1 * p.DI[0];
        const auto ijm5z = p.I - 5 * p.DI[1];
        const auto ijm4z = p.I - 4 * p.DI[1];
        const auto ijm3z = p.I - 3 * p.DI[1];
        const auto ijm2z = p.I - 2 * p.DI[1];
        const auto ijm1z = p.I - 1 * p.DI[1];
        const auto ijp5z = p.I + 5 * p.DI[1];
        const auto ijp4z = p.I + 4 * p.DI[1];
        const auto ijp3z = p.I + 3 * p.DI[1];
        const auto ijp2z = p.I + 2 * p.DI[1];
        const auto ijp1z = p.I + 1 * p.DI[1];
        const auto ijzm5 = p.I - 5 * p.DI[2];
        const auto ijzm4 = p.I - 4 * p.DI[2];
        const auto ijzm3 = p.I - 3 * p.DI[2];
        const auto ijzm2 = p.I - 2 * p.DI[2];
        const auto ijzm1 = p.I - 1 * p.DI[2];
        const auto ijzp5 = p.I + 5 * p.DI[2];
        const auto ijzp4 = p.I + 4 * p.DI[2];
        const auto ijzp3 = p.I + 3 * p.DI[2];
        const auto ijzp2 = p.I + 2 * p.DI[2];
        const auto ijzp1 = p.I + 1 * p.DI[2];

        // alpha
        diss_alpha    = 0;
        // beta
        diss_beta1    = 0;
        diss_beta2    = 0;
        diss_beta3    = 0;
        // ww
        diss_ww       = 0;
        // hhDD
        diss_hh11     = 0;
        diss_hh12     = 0;
        diss_hh13     = 0;
        diss_hh22     = 0;
        diss_hh23     = 0;
        diss_hh33     = 0;
        // trk
        diss_trk      = 0;
        // aaDD
        diss_aa11     = 0;
        diss_aa12     = 0;
        diss_aa13     = 0;
        diss_aa22     = 0;
        diss_aa23     = 0;
        diss_aa33     = 0;
        // gammat
        diss_gammat1  = 0;
        diss_gammat2  = 0;
        diss_gammat3  = 0;

        // ----------- Add dissipation --------------
        if(KO_order == 9){
          // alpha
          diss_alpha    = diss_alpha0 * KO_DISS_IX(alpha);
          // beta
          diss_beta1    = diss_beta0 * KO_DISS_IX(betx);
          diss_beta2    = diss_beta0 * KO_DISS_IX(bety);
          diss_beta3    = diss_beta0 * KO_DISS_IX(betz);
          // ww
          diss_ww       = diss_ww0 * KO_DISS_IX(conf_fac);
          // hhDD
          diss_hh11     = diss_hhDD0 * KO_DISS_IX(hxx);
          diss_hh12     = diss_hhDD0 * KO_DISS_IX(hxy);
          diss_hh13     = diss_hhDD0 * KO_DISS_IX(hxz);
          diss_hh22     = diss_hhDD0 * KO_DISS_IX(hyy);
          diss_hh23     = diss_hhDD0 * KO_DISS_IX(hyz);
          diss_hh33     = diss_hhDD0 * KO_DISS_IX(hzz);
          // trk
          diss_trk      = diss_trk0 * KO_DISS_IX(tracek);
          // aaDD
          diss_aa11     = diss_aaDD0 * KO_DISS_IX(axx);
          diss_aa12     = diss_aaDD0 * KO_DISS_IX(axy);
          diss_aa13     = diss_aaDD0 * KO_DISS_IX(axz);
          diss_aa22     = diss_aaDD0 * KO_DISS_IX(ayy);
          diss_aa23     = diss_aaDD0 * KO_DISS_IX(ayz);
          diss_aa33     = diss_aaDD0 * KO_DISS_IX(azz);
          // gammat
          diss_gammat1  = diss_gammat0 * KO_DISS_IX(gammatx);
          diss_gammat2  = diss_gammat0 * KO_DISS_IX(gammaty);
          diss_gammat3  = diss_gammat0 * KO_DISS_IX(gammatz);
        }
        else if(KO_order == 7){
          // alpha
          diss_alpha    = diss_alpha0 * KO_DISS_VII(alpha);
          // beta
          diss_beta1    = diss_beta0 * KO_DISS_VII(betx);
          diss_beta2    = diss_beta0 * KO_DISS_VII(bety);
          diss_beta3    = diss_beta0 * KO_DISS_VII(betz);
          // ww
          diss_ww       = diss_ww0   * KO_DISS_VII(conf_fac);
          // hhDD
          diss_hh11     = diss_hhDD0 * KO_DISS_VII(hxx);
          diss_hh12     = diss_hhDD0 * KO_DISS_VII(hxy);
          diss_hh13     = diss_hhDD0 * KO_DISS_VII(hxz);
          diss_hh22     = diss_hhDD0 * KO_DISS_VII(hyy);
          diss_hh23     = diss_hhDD0 * KO_DISS_VII(hyz);
          diss_hh33     = diss_hhDD0 * KO_DISS_VII(hzz);
          // trk
          diss_trk      = diss_trk0  * KO_DISS_VII(tracek);
          // aaDD
          diss_aa11     = diss_aaDD0 * KO_DISS_VII(axx);
          diss_aa12     = diss_aaDD0 * KO_DISS_VII(axy);
          diss_aa13     = diss_aaDD0 * KO_DISS_VII(axz);
          diss_aa22     = diss_aaDD0 * KO_DISS_VII(ayy);
          diss_aa23     = diss_aaDD0 * KO_DISS_VII(ayz);
          diss_aa33     = diss_aaDD0 * KO_DISS_VII(azz);
          // gammat
          diss_gammat1  = diss_gammat0 * KO_DISS_VII(gammatx);
          diss_gammat2  = diss_gammat0 * KO_DISS_VII(gammaty);
          diss_gammat3  = diss_gammat0 * KO_DISS_VII(gammatz);
        }
        else if(KO_order == 5){
          // alpha
          diss_alpha    = diss_alpha0 * KO_DISS_V(alpha);
          // beta
          diss_beta1    = diss_beta0 * KO_DISS_V(betx);
          diss_beta2    = diss_beta0 * KO_DISS_V(bety);
          diss_beta3    = diss_beta0 * KO_DISS_V(betz);
          // ww
          diss_ww       = diss_ww0    * KO_DISS_V(conf_fac);
          // hhDD
          diss_hh11     = diss_hhDD0 * KO_DISS_V(hxx);
          diss_hh12     = diss_hhDD0 * KO_DISS_V(hxy);
          diss_hh13     = diss_hhDD0 * KO_DISS_V(hxz);
          diss_hh22     = diss_hhDD0 * KO_DISS_V(hyy);
          diss_hh23     = diss_hhDD0 * KO_DISS_V(hyz);
          diss_hh33     = diss_hhDD0 * KO_DISS_V(hzz);
          // trk
          diss_trk      = diss_trk0  * KO_DISS_V(tracek);
          // aaDD
          diss_aa11     = diss_aaDD0 * KO_DISS_V(axx);
          diss_aa12     = diss_aaDD0 * KO_DISS_V(axy);
          diss_aa13     = diss_aaDD0 * KO_DISS_V(axz);
          diss_aa22     = diss_aaDD0 * KO_DISS_V(ayy);
          diss_aa23     = diss_aaDD0 * KO_DISS_V(ayz);
          diss_aa33     = diss_aaDD0 * KO_DISS_V(azz);
          // gammat
          diss_gammat1  = diss_gammat0 * KO_DISS_V(gammatx);
          diss_gammat2  = diss_gammat0 * KO_DISS_V(gammaty);
          diss_gammat3  = diss_gammat0 * KO_DISS_V(gammatz);
        }
        else{
          // CCTK_ERROR("Please select a valid KO dissipation order!");
          assert(0);
        }


        //------------ Write to grid functions ------
        rhs_alpha(p.I)    += diss_alpha;

        rhs_betx(p.I)     += diss_beta1;
        rhs_bety(p.I)     += diss_beta2;
        rhs_betz(p.I)     += diss_beta3;

        rhs_conf_fac(p.I) += diss_ww;

        rhs_hxx(p.I)      += diss_hh11;
        rhs_hxy(p.I)      += diss_hh12;
        rhs_hxz(p.I)      += diss_hh13;
        rhs_hyy(p.I)      += diss_hh22;
        rhs_hyz(p.I)      += diss_hh23;
        rhs_hzz(p.I)      += diss_hh33;

        rhs_tracek(p.I)   += diss_trk;

        rhs_axx(p.I)      += diss_aa11;
        rhs_axy(p.I)      += diss_aa12;
        rhs_axz(p.I)      += diss_aa13;
        rhs_ayy(p.I)      += diss_aa22;
        rhs_ayz(p.I)      += diss_aa23;
        rhs_azz(p.I)      += diss_aa33;

        rhs_gammatx(p.I)  += diss_gammat1;
        rhs_gammaty(p.I)  += diss_gammat2;
        rhs_gammatz(p.I)  += diss_gammat3;
  });
}

extern "C" void LeanBSSN_add_dissipation(CCTK_ARGUMENTS){    //scheduled add_dissipation routine

  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_add_dissipation;
  DECLARE_CCTK_PARAMETERS;

  switch (diss_order){
    case 5:
      LeanBSSN_add_dissipation_body<5>(CCTK_PASS_CTOC);
      break;
    case 7:
      LeanBSSN_add_dissipation_body<7>(CCTK_PASS_CTOC);
      break;
    case 9:
      LeanBSSN_add_dissipation_body<9>(CCTK_PASS_CTOC);
      break;
    default:
      CCTK_ERROR("Invalid KO dissipation order!");
  }
}

