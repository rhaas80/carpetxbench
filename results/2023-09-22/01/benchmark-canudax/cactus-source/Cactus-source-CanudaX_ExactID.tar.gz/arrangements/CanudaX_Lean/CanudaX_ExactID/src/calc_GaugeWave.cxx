/* intial data thorn: ExactID - gauge wave */
/*======================================================*/

#include "loop_device.hxx"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "exactid_utils.hxx"

using namespace Loop;

/* -------------------------------------------------------------------*/
void GaugeWave_ID (CCTK_ARGUMENTS) {
  DECLARE_CCTK_ARGUMENTSX_GaugeWave_ID;
  DECLARE_CCTK_PARAMETERS;

  //Structure of this function:
  //---------------------------------------------------------
  // 1) Define parameters
  // 2) Define coordinates
  // 3) Define metric functions
  // 4) Initialize gauge functions
  // 4) Define metric, curvature etc in Cartesian coordinates (x,y,z)


  CCTK_INFO("=== Begin Gauge Wave initial data ===");

  /*=== loops over full grid ===*/
  /*----------------------------*/

  grid.loop_all_device<0, 0, 0>(
    grid.nghostzones,
    [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
    CCTK_ATTRIBUTE_ALWAYS_INLINE {

      /*--------------------------------------------*/
      /*    compute phase of gauge wave             */
      /*--------------------------------------------*/

      CCTK_REAL phase = 2.0*Pi/wave_period *(p.x);

      /*--------------------------------------------*/
      /*    initialize gauge functions              */
      /*--------------------------------------------*/
      alp(p.I)      = sqrt(1.0 - wave_amplitude * sin(phase));
      //dtalp(p.I)    = Pi*wave_amplitude/wave_period * cos(phase) / sqrt(1.0 - wave_amplitude * sin(phase));
      betax(p.I)    = 0.0;
      betay(p.I)    = 0.0;
      betaz(p.I)    = 0.0;
      //dtbetax(p.I)  = 0.0;
      //dtbetay(p.I)  = 0.0;
      //dtbetaz(p.I)  = 0.0;

      /*--------------------------------------------*/
      /*    conformal metric in Cartesian coords    */
      /*--------------------------------------------*/
      gxx(p.I) = 1.0 - wave_amplitude * sin(phase);
      gxy(p.I) = 0.0;
      gxz(p.I) = 0.0;
      gyy(p.I) = 1.0;
      gyz(p.I) = 0.0;
      gzz(p.I) = 1.0;

      /*--------------------------------------------*/
      /*    Aij in Cartesian coords                 */
      /*--------------------------------------------*/
      kxx(p.I) = -Pi*wave_amplitude/wave_period * cos(phase) / sqrt(1.0 - wave_amplitude*sin(phase));
      kxy(p.I) = 0.0;
      kxz(p.I) = 0.0;
      kyy(p.I) = 0.0;
      kyz(p.I) = 0.0;
      kzz(p.I) = 0.0;

    });

  CCTK_INFO("=== End gauge wave initial data ===");
}
/* -------------------------------------------------------------------*/
