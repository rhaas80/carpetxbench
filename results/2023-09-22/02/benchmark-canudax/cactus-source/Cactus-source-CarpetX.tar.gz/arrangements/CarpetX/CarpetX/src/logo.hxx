#ifndef CARPETX_CARPETX_LOGO_HXX
#define CARPETX_CARPETX_LOGO_HXX

#include <string>

namespace CarpetX {
std::string logo();
} // namespace CarpetX

#endif // #ifndef CARPETX_CARPETX_LOGO_HXX
