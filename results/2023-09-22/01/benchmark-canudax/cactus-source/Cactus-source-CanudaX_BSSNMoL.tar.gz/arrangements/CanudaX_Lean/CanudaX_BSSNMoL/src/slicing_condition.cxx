// routine that enforces slicing condition with internal parameters

#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "evolve_utils.hxx"

namespace CanudaX_BSSNMoL{
  CCTK_REAL harmonic;
  CCTK_REAL onepluslog;
  CCTK_REAL shock_avoid;
}

extern "C" void LeanBSSN_slicing_condition(CCTK_ARGUMENTS){

  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_slicing_condition;
  DECLARE_CCTK_PARAMETERS;

  if( CCTK_EQUALS ( slicing_condition, "1+log"))
  {
    // 1+log slicing - arXiv:gr-qc/9412071
    CanudaX_BSSNMoL::harmonic     = 0;
    CanudaX_BSSNMoL::onepluslog   = 1;
    CanudaX_BSSNMoL::shock_avoid  = 0;
  }

  else if( CCTK_EQUALS ( slicing_condition, "shock-avoiding"))
  {
    // shock-avoiding condition  -  arXiv:gr-qc/9609015
    CanudaX_BSSNMoL::harmonic     = 0;
    CanudaX_BSSNMoL::onepluslog   = 0;
    CanudaX_BSSNMoL::shock_avoid  = 1;
  }

  else if( CCTK_EQUALS ( slicing_condition, "harmonic"))
  {
    // harmonic slicing
    CanudaX_BSSNMoL::harmonic     = 1;
    CanudaX_BSSNMoL::onepluslog   = 0;
    CanudaX_BSSNMoL::shock_avoid  = 0;
  }

  else if( CCTK_EQUALS (slicing_condition, "geodesic"))
  {
    // geodesic slicing
    CanudaX_BSSNMoL::harmonic     = 0;
    CanudaX_BSSNMoL::onepluslog   = 0;
    CanudaX_BSSNMoL::shock_avoid  = 0;
  }
  else{
    CCTK_ERROR("Undefined slicing condition!");
  }
}
