#include "boundaries_impl.hxx"

namespace CarpetX {

template void BoundaryCondition::apply_on_face<INT, INT, POS>() const;

} // namespace CarpetX
