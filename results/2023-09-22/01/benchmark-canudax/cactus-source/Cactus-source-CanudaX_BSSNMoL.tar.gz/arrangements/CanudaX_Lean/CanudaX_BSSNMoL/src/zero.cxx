#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include <math.h>
#include "loop_device.hxx"

#define Pi  3.14159265358979323846264338328

void LeanBSSN_zero( CCTK_ARGUMENTS )
{

  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_zero
  DECLARE_CCTK_PARAMETERS

  grid.loop_all_device<0, 0, 0>(
      grid.nghostzones,
      [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
          CCTK_ATTRIBUTE_ALWAYS_INLINE {

            conf_fac(p.I) = 0.;

            hxx(p.I) = 0.;
            hxy(p.I) = 0.;
            hxz(p.I) = 0.;
            hyy(p.I) = 0.;
            hyz(p.I) = 0.;
            hzz(p.I) = 0.;

            tracek(p.I) = 0.;

            axx(p.I) = 0.;
            axy(p.I) = 0.;
            axz(p.I) = 0.;
            ayy(p.I) = 0.;
            ayz(p.I) = 0.;
            azz(p.I) = 0.;

            gammatx(p.I) = 0.;
            gammaty(p.I) = 0.;
            gammatz(p.I) = 0.;

            alpha(p.I) = 0.;

            betx(p.I) = 0.;
            bety(p.I) = 0.;
            betz(p.I) = 0.;

            rhs_conf_fac(p.I) = 0.;

            rhs_hxx(p.I) = 0.;
            rhs_hxy(p.I) = 0.;
            rhs_hxz(p.I) = 0.;
            rhs_hyy(p.I) = 0.;
            rhs_hyz(p.I) = 0.;
            rhs_hzz(p.I) = 0.;

            rhs_tracek(p.I) = 0.;

            rhs_axx(p.I) = 0.;
            rhs_axy(p.I) = 0.;
            rhs_axz(p.I) = 0.;
            rhs_ayy(p.I) = 0.;
            rhs_ayz(p.I) = 0.;
            rhs_azz(p.I) = 0.;

            rhs_gammatx(p.I) = 0.;
            rhs_gammaty(p.I) = 0.;
            rhs_gammatz(p.I) = 0.;

            rhs_alpha(p.I) = 0.;

            rhs_betx(p.I) = 0.;
            rhs_bety(p.I) = 0.;
            rhs_betz(p.I) = 0.;

          });

}


void LeanBSSN_zero_constr( CCTK_ARGUMENTS )
{

  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_zero_constr
  DECLARE_CCTK_PARAMETERS

  grid.loop_all_device<0, 0, 0>(
      grid.nghostzones,
      [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
          CCTK_ATTRIBUTE_ALWAYS_INLINE {

            hc(p.I)  = 0.;
            mcx(p.I) = 0.;
            mcy(p.I) = 0.;
            mcz(p.I) = 0.;

          });
}
