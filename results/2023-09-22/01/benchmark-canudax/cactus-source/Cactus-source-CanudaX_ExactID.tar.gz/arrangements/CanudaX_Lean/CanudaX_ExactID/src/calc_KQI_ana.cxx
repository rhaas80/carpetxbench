/* intial data thorn: ExactID */
/*======================================================*/

#include "loop_device.hxx"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "exactid_utils.hxx"

using namespace Loop;

/* -------------------------------------------------------------------*/
enum class KQI_gauge_choice_t {analytic, absolute, precollapsed};

extern "C" void KQI_analytic (CCTK_ARGUMENTS){

  DECLARE_CCTK_ARGUMENTSX_KQI_analytic;
  DECLARE_CCTK_PARAMETERS;

  //Structure of this function:
  //---------------------------------------------------------
  // 1) Define parameters
  // 2) Define coordinates
  // 3) Define metric functions
  // 4) Initialize gauge functions
  // 4) Define metric, curvature etc in Cartesian coordinates (x,y,z)

  // CCTK_INFO("=== Begin KQI initial data ===");

  // Mass, spin, and position of the black hole
  CCTK_REAL mass   =  KQI_m_plus;
  CCTK_REAL spin   =  KQI_spin_plus;
  CCTK_REAL pos[3] = {KQI_pos_plus[0],
                      KQI_pos_plus[1],
                      KQI_pos_plus[2]};

  // Choices for the lapse and shift
  KQI_gauge_choice_t initial_lapse_choice;
  KQI_gauge_choice_t initial_shift_choice;

  if (CCTK_Equals(initial_lapse, "KQI_ana" )) {
    // analytic continuation
    initial_lapse_choice = KQI_gauge_choice_t::analytic;

  } else if (CCTK_Equals(initial_lapse, "KQI_abs" )) {
    // absolute value of lapse
    // Discouraged. Better to use the analytic continuation of KQI_ana.
    initial_lapse_choice = KQI_gauge_choice_t::absolute;

  } else if (CCTK_Equals(initial_lapse, "KQI_prec" )) {
  // precollapsed lapse
    initial_lapse_choice = KQI_gauge_choice_t::precollapsed;
  }

  if (CCTK_Equals(initial_shift, "KQI_ana" )) {
  // analytic continuation
    initial_shift_choice = KQI_gauge_choice_t::analytic;
  }

        /*=== loops over full grid ===*/
        /*----------------------------*/
  grid.loop_all_device<0, 0, 0>(
      grid.nghostzones,
      [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
          CCTK_ATTRIBUTE_ALWAYS_INLINE {

    /*=== define BH parameters ===*/
    /*----------------------------*/
    CCTK_REAL mass2, spin2, rBLp, rBLm;
    mass2 = mass * mass;
    spin2 = spin * spin;
    rBLp  = mass + sqrt( mass2 - spin2 );
    rBLm  = mass - sqrt( mass2 - spin2 );

    /*----------------------------*/

    /*=== define position parameters ===*/
    /*----------------------------------*/
    // Define coordinates
    CCTK_REAL xx, yy, zz;
    xx = p.x - pos[0];
    yy = p.y - pos[1];
    zz = p.z - pos[2];

    CCTK_REAL RR, RR2;
    RR2 = xx * xx + yy * yy + zz * zz;
    if( RR2 < pow( eps_r, 2 ) )
        RR2 = pow( eps_r, 2 );
    RR  = sqrt( RR2 );

    CCTK_REAL rho, rho2, rho3;
    rho2 = xx * xx + yy * yy;
    if( rho2 < pow( eps_r, 2 ) )
        rho2 = pow( eps_r, 2 );
    rho  = sqrt( rho2 );
    rho3 = rho2 * rho;

    CCTK_REAL ctheta, ctheta2;
    ctheta  = zz / RR;
    ctheta2 = ctheta * ctheta;

    CCTK_REAL stheta, stheta2;
    stheta  = rho / RR;
    stheta2 = stheta  * stheta;
    /*----------------------------------*/

    /*=== define metric functions ======*/
    /*----------------------------------*/
    CCTK_REAL rBL, rBL2;
    rBL  = RR * ( 1.0 + 0.25 * rBLp / RR ) * ( 1.0 + 0.25 * rBLp / RR );
    rBL2 = rBL * rBL;

    CCTK_REAL drBLdR;
    drBLdR = 1.0 - rBLp*rBLp / ( 16.0 * RR2 );

    CCTK_REAL Delt, Sigm, Sigm2, fctFF;
    Delt  = rBL2 + spin2 - 2 * mass * rBL;
    Sigm  = rBL2 + spin2 * ctheta2;
    Sigm2 = Sigm * Sigm;
    fctFF = ( rBL2 + spin2 ) * ( rBL2 + spin2 ) - Delt * spin2 * stheta2;

    CCTK_REAL psi04;
    psi04 = Sigm / RR2;

    CCTK_REAL fctGG, fctHH;
    fctGG = rBLm / ( RR2 * ( rBL - rBLm ) );
    fctHH = ( 2.0 * mass * rBL + Sigm ) / ( RR2 * Sigm2 );

    CCTK_REAL detgij;
    detgij = pow( psi04, 3) * ( 1.0 + RR2 * fctGG ) * ( 1.0 + spin2 * rho2 * fctHH );

    /*----------------------------------*/

    /*=== initialize gauge functions ===*/
    /*----------------------------------*/
    switch (initial_lapse_choice) {
      case KQI_gauge_choice_t::analytic:
        alp(p.I) = ( 4.0*RR - rBLp) * sqrt( rBL -rBLm )  /
               sqrt( 16.0*RR * ( rBL2 + spin2 * ( 1.0 + 2.0*mass*rBL * stheta2 / Sigm ) ) );
        break;

      case KQI_gauge_choice_t::absolute:
        alp(p.I) = sqrt( Delt * Sigm / fctFF );
        break;

      case KQI_gauge_choice_t::precollapsed:
        alp(p.I) = pow( detgij, -1./6 );
        break;

      default:
        alp(p.I) = 1.0;
    }

    switch (initial_shift_choice) {
      case KQI_gauge_choice_t::analytic:
        CCTK_REAL bphi;
        bphi = 2.0 * spin * mass * rBL / fctFF;

        betax(p.I) =   yy * bphi;
        betay(p.I) = - xx * bphi;
        betaz(p.I) = 0.0;
        break;

      default:
        betax(p.I) = 0.0;
        betay(p.I) = 0.0;
        betaz(p.I) = 0.0;
    }

    /*----------------------------------*/

    /*=== conformal metric in Cartesian coords ===*/
    /*--------------------------------------------*/

    gxx(p.I) = psi04 * ( 1.0 + xx*xx * fctGG + spin2 * yy*yy * fctHH );
    gxy(p.I) = psi04 * (       xx*yy * fctGG - spin2 * xx*yy * fctHH );
    gxz(p.I) = psi04 * (       xx*zz * fctGG );
    gyy(p.I) = psi04 * ( 1.0 + yy*yy * fctGG + spin2 * xx*xx * fctHH );
    gyz(p.I) = psi04 * (       yy*zz * fctGG );
    gzz(p.I) = psi04 * ( 1.0 + zz*zz * fctGG );

    /*--------------------------------------------*/

    /*=== Aij in Cartesian coords ===*/
    /*-------------------------------*/

    CCTK_REAL auxKij, facKij, facKijRho, facKijZ;

    auxKij    = 2.0 * rBL2 * ( rBL2 + spin2 ) + Sigm * ( rBL2 - spin2 );
    facKij    = alp(p.I) * spin * mass * stheta2 / ( RR2 * rho3 * Delt * Sigm2 );
    facKijRho = 2.0 * zz  * spin2 * rBL * Delt * ctheta * stheta - rho * RR * drBLdR * auxKij;
    facKijZ   = 2.0 * rho * spin2 * rBL * Delt * ctheta * stheta + zz  * RR * drBLdR * auxKij;

    kxx(p.I) =   2.0 * xx * yy   * facKij * facKijRho;
    kxy(p.I) = ( yy*yy - xx*xx ) * facKij * facKijRho;
    kxz(p.I) = - yy * rho        * facKij * facKijZ;
    kyy(p.I) = - 2.0 * xx * yy   * facKij * facKijRho;
    kyz(p.I) =   xx * rho        * facKij * facKijZ;
    kzz(p.I) =   0.0;

    /*---------------------------------------*/
    // Poke spacetime variables?
    CCTK_REAL rr = sqrt(pow(p.x-x0_poke,2)+pow(p.y-y0_poke,2)+pow(p.z-z0_poke,2));
    CCTK_REAL gauss_poke = exp(-0.5*pow((rr-r0_poke)/sigma_poke,2));

    alp(p.I)   += alp_poke * gauss_poke;

    betax(p.I) += bet_poke * gauss_poke;
    betay(p.I) += bet_poke * gauss_poke;
    betaz(p.I) += bet_poke * gauss_poke;

    gxx(p.I)   += met_poke * gauss_poke;
    gxy(p.I)   += met_poke * gauss_poke;
    gxz(p.I)   += met_poke * gauss_poke;
    gyy(p.I)   += met_poke * gauss_poke;
    gyz(p.I)   += met_poke * gauss_poke;
    gzz(p.I)   += met_poke * gauss_poke;

    kxx(p.I)   += curv_poke * gauss_poke;
    kxy(p.I)   += curv_poke * gauss_poke;
    kxz(p.I)   += curv_poke * gauss_poke;
    kyy(p.I)   += curv_poke * gauss_poke;
    kyz(p.I)   += curv_poke * gauss_poke;
    kzz(p.I)   += curv_poke * gauss_poke;

  });
/*=== end of loops over grid ===*/
/*------------------------------*/

//  CCTK_INFO("=== End KQI initial data ===");

}
/* -------------------------------------------------------------------*/
