// adm_vs_bssn.c : Functions for converting between ADM and BSSN variables
//
//=============================================================================

#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "loop_device.hxx"
#include "evolve_utils.hxx"

// 1st derivative - 6th order
#define FD_DX_VI(gf) \
  ( + gf(Ip3dx) - 9*gf(Ip2dx) + 45*gf(Ip1dx) - 45*gf(Im1dx) + 9*gf(Im2dx) - gf(Im3dx) ) * inv60dx
#define FD_DY_VI(gf) \
  ( + gf(Ip3dy) - 9*gf(Ip2dy) + 45*gf(Ip1dy) - 45*gf(Im1dy) + 9*gf(Im2dy) - gf(Im3dy) ) * inv60dy
#define FD_DZ_VI(gf) \
  ( + gf(Ip3dz) - 9*gf(Ip2dz) + 45*gf(Ip1dz) - 45*gf(Im1dz) + 9*gf(Im2dz) - gf(Im3dz) ) * inv60dz
// 1st derivative - 4th order
#define FD_DX_IV(gf) \
  ( - gf(Ip2dx) + 8*gf(Ip1dx) - 8*gf(Im1dx) + gf(Im2dx) ) * inv12dx
#define FD_DY_IV(gf) \
  ( - gf(Ip2dy) + 8*gf(Ip1dy) - 8*gf(Im1dy) + gf(Im2dy) ) * inv12dy
#define FD_DZ_IV(gf) \
  ( - gf(Ip2dz) + 8*gf(Ip1dz) - 8*gf(Im1dz) + gf(Im2dz) ) * inv12dz

using namespace CanudaX_BSSNMoL;
using namespace std;
using namespace Loop;

template <int FD_order> void LeanBSSN_gammat_body( CCTK_ARGUMENTS )
{
  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_gammat;
  DECLARE_CCTK_PARAMETERS;

  grid.loop_int_device<0, 0, 0>(
      grid.nghostzones,
      [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
          CCTK_ATTRIBUTE_ALWAYS_INLINE {

    CCTK_REAL hhDD[3][3], hhUU[3][3], dethh;
    CCTK_REAL gammat[3];
    CCTK_REAL d1_hh11[3], d1_hh12[3], d1_hh13[3], d1_hh22[3], d1_hh23[3], d1_hh33[3];
    CCTK_REAL d1_hh[3][3][3];
    CCTK_REAL cf1[3][3][3], cf2[3][3][3];
    CCTK_INT  i,a, b, c, m, n;

    hhDD[0][0] = hxx(p.I);
    hhDD[0][1] = hxy(p.I);
    hhDD[0][2] = hxz(p.I);
    hhDD[1][1] = hyy(p.I);
    hhDD[1][2] = hyz(p.I);
    hhDD[2][2] = hzz(p.I);
    hhDD[1][0] = hhDD[0][1];
    hhDD[2][0] = hhDD[0][2];
    hhDD[2][1] = hhDD[1][2];


    //------------- Invert metric ---------------
    //invert_metric(hu, hh)
    dethh =     hhDD[0][0] * hhDD[1][1] * hhDD[2][2]
          + 2 * hhDD[0][1] * hhDD[0][2] * hhDD[1][2]
          -     hhDD[0][0] * hhDD[1][2] * hhDD[1][2]
          -     hhDD[1][1] * hhDD[0][2] * hhDD[0][2]
          -     hhDD[2][2] * hhDD[0][1] * hhDD[0][1];

    hhUU[0][0] = (hhDD[1][1] * hhDD[2][2] - hhDD[1][2] * hhDD[1][2]) / dethh;
    hhUU[1][1] = (hhDD[0][0] * hhDD[2][2] - hhDD[0][2] * hhDD[0][2]) / dethh;
    hhUU[2][2] = (hhDD[0][0] * hhDD[1][1] - hhDD[0][1] * hhDD[0][1]) / dethh;
    hhUU[0][1] = (hhDD[0][2] * hhDD[1][2] - hhDD[0][1] * hhDD[2][2]) / dethh;
    hhUU[0][2] = (hhDD[0][1] * hhDD[1][2] - hhDD[0][2] * hhDD[1][1]) / dethh;
    hhUU[1][2] = (hhDD[0][2] * hhDD[0][1] - hhDD[1][2] * hhDD[0][0]) / dethh;
    hhUU[1][0] = hhUU[0][1];
    hhUU[2][0] = hhUU[0][2];
    hhUU[2][1] = hhUU[1][2];
    //-------------------------------------------


    //----------- calculate derivatives ----------

    //---------------------------
    // indices
    vect<int, 3> Ip3dx = p.I + 3*p.DI[0];
    vect<int, 3> Ip3dy = p.I + 3*p.DI[1];
    vect<int, 3> Ip3dz = p.I + 3*p.DI[2];
    vect<int, 3> Ip2dx = p.I + 2*p.DI[0];
    vect<int, 3> Ip2dy = p.I + 2*p.DI[1];
    vect<int, 3> Ip2dz = p.I + 2*p.DI[2];
    vect<int, 3> Ip1dx = p.I +   p.DI[0];
    vect<int, 3> Ip1dy = p.I +   p.DI[1];
    vect<int, 3> Ip1dz = p.I +   p.DI[2];
    vect<int, 3> Im3dx = p.I - 3*p.DI[0];
    vect<int, 3> Im3dy = p.I - 3*p.DI[1];
    vect<int, 3> Im3dz = p.I - 3*p.DI[2];
    vect<int, 3> Im2dx = p.I - 2*p.DI[0];
    vect<int, 3> Im2dy = p.I - 2*p.DI[1];
    vect<int, 3> Im2dz = p.I - 2*p.DI[2];
    vect<int, 3> Im1dx = p.I -   p.DI[0];
    vect<int, 3> Im1dy = p.I -   p.DI[1];
    vect<int, 3> Im1dz = p.I -   p.DI[2];

    // 6th order coeffs
    CCTK_REAL inv60dx = 1.0/(60*p.DX[0]);
    CCTK_REAL inv60dy = 1.0/(60*p.DX[1]);
    CCTK_REAL inv60dz = 1.0/(60*p.DX[2]);
    // 4th order coeffs
    CCTK_REAL inv12dx = 1.0/(12*p.DX[0]);
    CCTK_REAL inv12dy = 1.0/(12*p.DX[1]);
    CCTK_REAL inv12dz = 1.0/(12*p.DX[2]);


    // FD order = 6
    if(FD_order == 6){
      //----------------------
      //d1_hhDD
      //------
      d1_hh11[0] = FD_DX_VI(hxx);
      d1_hh12[0] = FD_DX_VI(hxy);
      d1_hh13[0] = FD_DX_VI(hxz);
      d1_hh22[0] = FD_DX_VI(hyy);
      d1_hh23[0] = FD_DX_VI(hyz);
      d1_hh33[0] = FD_DX_VI(hzz);
      //---------
      d1_hh11[1] = FD_DY_VI(hxx);
      d1_hh12[1] = FD_DY_VI(hxy);
      d1_hh13[1] = FD_DY_VI(hxz);
      d1_hh22[1] = FD_DY_VI(hyy);
      d1_hh23[1] = FD_DY_VI(hyz);
      d1_hh33[1] = FD_DY_VI(hzz);
      //--------
      d1_hh11[2] = FD_DZ_VI(hxx);
      d1_hh12[2] = FD_DZ_VI(hxy);
      d1_hh13[2] = FD_DZ_VI(hxz);
      d1_hh22[2] = FD_DZ_VI(hyy);
      d1_hh23[2] = FD_DZ_VI(hyz);
      d1_hh33[2] = FD_DZ_VI(hzz);
    } // if (FD_order == 6)

    // FD order 4
    else if(FD_order == 4){
      //---------------------------------------
      //d1_hhDD
      //----------
      d1_hh11[0] = FD_DX_IV(hxx);
      d1_hh12[0] = FD_DX_IV(hxy);
      d1_hh13[0] = FD_DX_IV(hxz);
      d1_hh22[0] = FD_DX_IV(hyy);
      d1_hh23[0] = FD_DX_IV(hyz);
      d1_hh33[0] = FD_DX_IV(hzz);
      //---------
      d1_hh11[1] = FD_DY_IV(hxx);
      d1_hh12[1] = FD_DY_IV(hxy);
      d1_hh13[1] = FD_DY_IV(hxz);
      d1_hh22[1] = FD_DY_IV(hyy);
      d1_hh23[1] = FD_DY_IV(hyz);
      d1_hh33[1] = FD_DY_IV(hzz);
      //--------
      d1_hh11[2] = FD_DZ_IV(hxx);
      d1_hh12[2] = FD_DZ_IV(hxy);
      d1_hh13[2] = FD_DZ_IV(hxz);
      d1_hh22[2] = FD_DZ_IV(hyy);
      d1_hh23[2] = FD_DZ_IV(hyz);
      d1_hh33[2] = FD_DZ_IV(hzz);
    }

    for(i=0; i<3; i++){
      d1_hh[0][0][i] = d1_hh11[i];
      d1_hh[0][1][i] = d1_hh12[i];
      d1_hh[0][2][i] = d1_hh13[i];
      d1_hh[1][1][i] = d1_hh22[i];
      d1_hh[1][2][i] = d1_hh23[i];
      d1_hh[2][2][i] = d1_hh33[i];
      d1_hh[1][0][i] = d1_hh[0][1][i];
      d1_hh[2][0][i] = d1_hh[0][2][i];
      d1_hh[2][1][i] = d1_hh[1][2][i];
    }
    //-------------------------------------------


    //------------ Connections ------------------
    for (a=0; a<3; a++) {
      for (b=0; b<3; b++) {
        for (c=0; c<3; c++) {
          cf1[a][b][c] = 0.5 * (d1_hh[a][b][c] + d1_hh[a][c][b] - d1_hh[b][c][a]);
        }
      }
    }

    for (a=0; a<3; a++) {
      for (b=0; b<3; b++) {
        for (c=0; c<3; c++) {
          cf2[a][b][c] = 0;
          for (m=0; m<3; m++)
            cf2[a][b][c] += hhUU[a][m] * cf1[m][b][c];
        }
      }
    }
    //-------------------------------------------


    //------------ Gammat ------------------------
    for (a=0; a<3; a++) {
      gammat[a] = 0;
      for (m=0; m<3; m++) {
        for (n=0; n<3; n++) {
          gammat[a] += hhUU[m][n] * cf2[a][m][n];
        }
      }
    }
    //-------------------------------------------


    //------------ Write to gf ------------------
    gammatx(p.I) = gammat[0];
    gammaty(p.I) = gammat[1];
    gammatz(p.I) = gammat[2];
    //-------------------------------------------

  });
}

extern "C" void LeanBSSN_gammat(CCTK_ARGUMENTS){    //scheduled adm to bssn routine

  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_gammat;
  DECLARE_CCTK_PARAMETERS;

  switch (derivs_order){
    case 4:
      LeanBSSN_gammat_body<4>(CCTK_PASS_CTOC);
      break;
    case 6:
      LeanBSSN_gammat_body<6>(CCTK_PASS_CTOC);
      break;
    default:
      CCTK_ERROR("Invalid FD approximation order!");
  }
}

//
//===========================================================================
//

extern "C" void LeanBSSN_adm2bssn( CCTK_ARGUMENTS )
{
  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_adm2bssn;
  DECLARE_CCTK_PARAMETERS;

  grid.loop_all_device<0, 0, 0>(
      grid.nghostzones,
      [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
          CCTK_ATTRIBUTE_ALWAYS_INLINE {

      CCTK_REAL ggDD[3][3], ggUU[3][3], kkDD[3][3], hhDD[3][3], aaDD[3][3];
      CCTK_REAL detg;
      CCTK_REAL ww, trk;
      CCTK_INT  a, b;

      //------------ Get local vars ---------------
      ggDD[0][0] = gxx(p.I);
      ggDD[0][1] = gxy(p.I);
      ggDD[0][2] = gxz(p.I);
      ggDD[1][1] = gyy(p.I);
      ggDD[1][2] = gyz(p.I);
      ggDD[2][2] = gzz(p.I);
      ggDD[1][0] = ggDD[0][1];
      ggDD[2][0] = ggDD[0][2];
      ggDD[2][1] = ggDD[1][2];

      kkDD[0][0] = kxx(p.I);
      kkDD[0][1] = kxy(p.I);
      kkDD[0][2] = kxz(p.I);
      kkDD[1][1] = kyy(p.I);
      kkDD[1][2] = kyz(p.I);
      kkDD[2][2] = kzz(p.I);
      kkDD[1][0] = kkDD[0][1];
      kkDD[2][0] = kkDD[0][2];
      kkDD[2][1] = kkDD[1][2];

      // Copy lapse and shift from ADMBase to CanudaX_BSSNMoL's own grid function
      alpha(p.I) = alp(p.I);

      betx(p.I)  = betax(p.I);
      bety(p.I)  = betay(p.I);
      betz(p.I)  = betaz(p.I);
      //-------------------------------------------


      //------------- Calculate detg --------------
      //det_metric(detg, ggDD);
      detg =      ggDD[0][0] * ggDD[1][1] * ggDD[2][2]
            + 2 * ggDD[0][1] * ggDD[0][2] * ggDD[1][2]
            -     ggDD[0][0] * ggDD[1][2] * ggDD[1][2]
            -     ggDD[1][1] * ggDD[0][2] * ggDD[0][2]
            -     ggDD[2][2] * ggDD[0][1] * ggDD[0][1];
      //-------------------------------------------


      //------------- Invert metric ---------------
      //invert_metric(gu, ggDD);
      ggUU[0][0] = (ggDD[1][1] * ggDD[2][2] - ggDD[1][2] * ggDD[1][2]) / detg;
      ggUU[1][1] = (ggDD[0][0] * ggDD[2][2] - ggDD[0][2] * ggDD[0][2]) / detg;
      ggUU[2][2] = (ggDD[0][0] * ggDD[1][1] - ggDD[0][1] * ggDD[0][1]) / detg;
      ggUU[0][1] = (ggDD[0][2] * ggDD[1][2] - ggDD[0][1] * ggDD[2][2]) / detg;
      ggUU[0][2] = (ggDD[0][1] * ggDD[1][2] - ggDD[0][2] * ggDD[1][1]) / detg;
      ggUU[1][2] = (ggDD[0][2] * ggDD[0][1] - ggDD[1][2] * ggDD[0][0]) / detg;
      ggUU[1][0] = ggUU[0][1];
      ggUU[2][0] = ggUU[0][2];
      ggUU[2][1] = ggUU[1][2];
      //-------------------------------------------


      //------------ Convert to BSSN --------------
      trk = 0;
      for (a=0; a<3; a++) {
        for (b=0; b<3; b++) {
          trk += ggUU[a][b] * kkDD[a][b];
        }
      }

      ww = pow(detg, (-1.0/6.0));
      for (a=0; a<3; a++) {
        for (b=0; b<3; b++) {
          hhDD[a][b] = ww*ww * ggDD[a][b];
          aaDD[a][b] = ww*ww * (kkDD[a][b] - trk / 3 * ggDD[a][b]);
        }
      }
      //-------------------------------------------


      //------------ Write to grid functions ------
      conf_fac(p.I)     = ww;
      if( impose_conf_fac_floor_at_initial )
        if( conf_fac(p.I) < conf_fac_floor ) conf_fac(p.I) = conf_fac_floor;

      if( precollapsed_lapse )
        alpha(p.I)   = ww;

      if( rescale_shift_initial ) {
        betx(p.I)    = ww * betax(p.I);
        bety(p.I)    = ww * betay(p.I);
        betz(p.I)    = ww * betaz(p.I);
      }

      hxx(p.I)     = hhDD[0][0];
      hxy(p.I)     = hhDD[0][1];
      hxz(p.I)     = hhDD[0][2];
      hyy(p.I)     = hhDD[1][1];
      hyz(p.I)     = hhDD[1][2];
      hzz(p.I)     = hhDD[2][2];

      tracek(p.I)  = trk;

      axx(p.I)     = aaDD[0][0];
      axy(p.I)     = aaDD[0][1];
      axz(p.I)     = aaDD[0][2];
      ayy(p.I)     = aaDD[1][1];
      ayz(p.I)     = aaDD[1][2];
      azz(p.I)     = aaDD[2][2];

      // Just to make sure gammat has no uninitialized values anywhere
      gammatx(p.I)     = 0;
      gammaty(p.I)     = 0;
      gammatz(p.I)     = 0;
      //-------------------------------------------

  });
}

//
//===========================================================================
//

extern "C" void LeanBSSN_bssn2adm( CCTK_ARGUMENTS )
{
  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_bssn2adm;
  DECLARE_CCTK_PARAMETERS;

  grid.loop_all_device<0, 0, 0>(
      grid.nghostzones,
      [=] CCTK_DEVICE CCTK_HOST(const Loop::PointDesc &p)
          CCTK_ATTRIBUTE_ALWAYS_INLINE {
    gxx(p.I) = hxx(p.I) / (conf_fac(p.I) * conf_fac(p.I));
    gxy(p.I) = hxy(p.I) / (conf_fac(p.I) * conf_fac(p.I));
    gxz(p.I) = hxz(p.I) / (conf_fac(p.I) * conf_fac(p.I));
    gyy(p.I) = hyy(p.I) / (conf_fac(p.I) * conf_fac(p.I));
    gyz(p.I) = hyz(p.I) / (conf_fac(p.I) * conf_fac(p.I));
    gzz(p.I) = hzz(p.I) / (conf_fac(p.I) * conf_fac(p.I));

    kxx(p.I) = axx(p.I) / (conf_fac(p.I) * conf_fac(p.I)) + tracek(p.I) * gxx(p.I) / 3;
    kxy(p.I) = axy(p.I) / (conf_fac(p.I) * conf_fac(p.I)) + tracek(p.I) * gxy(p.I) / 3;
    kxz(p.I) = axz(p.I) / (conf_fac(p.I) * conf_fac(p.I)) + tracek(p.I) * gxz(p.I) / 3;
    kyy(p.I) = ayy(p.I) / (conf_fac(p.I) * conf_fac(p.I)) + tracek(p.I) * gyy(p.I) / 3;
    kyz(p.I) = ayz(p.I) / (conf_fac(p.I) * conf_fac(p.I)) + tracek(p.I) * gyz(p.I) / 3;
    kzz(p.I) = azz(p.I) / (conf_fac(p.I) * conf_fac(p.I)) + tracek(p.I) * gzz(p.I) / 3;

    // Store lapse and shift in ADMBase's grid function
    alp(p.I) = alpha(p.I);

    betax(p.I) = betx(p.I);
    betay(p.I) = bety(p.I);
    betaz(p.I) = betz(p.I);

  });

}
