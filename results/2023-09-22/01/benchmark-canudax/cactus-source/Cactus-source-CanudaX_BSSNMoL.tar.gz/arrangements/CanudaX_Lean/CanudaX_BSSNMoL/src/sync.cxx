#include <cctk.h>
#include <cctk_Arguments.h>

namespace CanudaX_BSSNMoL {

extern "C" void CanudaX_Sync(CCTK_ARGUMENTS) { DECLARE_CCTK_ARGUMENTS_CanudaX_Sync; }

} // namespace CanudaX_BSSNMoL

