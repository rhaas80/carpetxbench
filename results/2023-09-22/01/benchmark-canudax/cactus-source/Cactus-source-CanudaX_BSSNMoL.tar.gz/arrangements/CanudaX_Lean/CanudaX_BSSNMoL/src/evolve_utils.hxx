// evolve_utils: Misc stuff that is needed for evolution!
//
//=============================================================================

#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "loop_device.hxx"

using namespace std;
using namespace Loop;

namespace CanudaX_BSSNMoL{

extern CCTK_REAL harmonic, onepluslog, shock_avoid;

void apply_jacobian(CCTK_REAL dvar[3], CCTK_REAL jac[3][3]);
void apply_jacobian2(CCTK_REAL ddvar[3][3], CCTK_REAL dvar[3], CCTK_REAL jac[3][3], CCTK_REAL hes[3][3][3]);

} // namespace CanudaX_BSSNMoL


void LeanBSSN_remove_trA( CCTK_ARGUMENTS );
void LeanBSSN_reset_detmetric( CCTK_ARGUMENTS );
void LeanBSSN_impose_conf_fac_floor( CCTK_ARGUMENTS );
