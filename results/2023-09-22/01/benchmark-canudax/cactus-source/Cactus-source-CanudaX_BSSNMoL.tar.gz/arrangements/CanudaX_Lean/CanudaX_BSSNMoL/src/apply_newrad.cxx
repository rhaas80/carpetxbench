// add_dissipation: add KO dissipation to rhs
//=============================================================================
#include <iostream>
#include <cmath>
#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"
#include "loop_device.hxx"
#include "evolve_utils.hxx"
#include "newradx.hxx"

using namespace CanudaX_BSSNMoL;
using namespace Loop;
using namespace std;
using namespace NewRadX;

namespace CanudaX_BSSNMoL{

extern "C" void LeanBSSN_apply_boundary_conditions(CCTK_ARGUMENTS){
  DECLARE_CCTK_ARGUMENTSX_LeanBSSN_apply_boundary_conditions;
  DECLARE_CCTK_PARAMETERS;
  
  if (CCTK_Equals(boundary_conditions, "radiative")) {
    NewRadX_Apply(cctkGH, alpha,    rhs_alpha,    1, 1, n_alpha);

    NewRadX_Apply(cctkGH, betx,     rhs_betx,     0, 1, n_beta);
    NewRadX_Apply(cctkGH, bety,     rhs_bety,     0, 1, n_beta);
    NewRadX_Apply(cctkGH, betz,     rhs_betz,     0, 1, n_beta);

    NewRadX_Apply(cctkGH, conf_fac, rhs_conf_fac, 1, 1, n_conf_fac);

    NewRadX_Apply(cctkGH, hxx,      rhs_hxx,      1, 1, n_hij);
    NewRadX_Apply(cctkGH, hxy,      rhs_hxy,      0, 1, n_hij);
    NewRadX_Apply(cctkGH, hxz,      rhs_hxz,      0, 1, n_hij);
    NewRadX_Apply(cctkGH, hyy,      rhs_hyy,      1, 1, n_hij);
    NewRadX_Apply(cctkGH, hyz,      rhs_hyz,      0, 1, n_hij);
    NewRadX_Apply(cctkGH, hzz,      rhs_hzz,      1, 1, n_hij);

    NewRadX_Apply(cctkGH, gammatx,  rhs_gammatx,  0, 1, n_gammat);
    NewRadX_Apply(cctkGH, gammaty,  rhs_gammaty,  0, 1, n_gammat);
    NewRadX_Apply(cctkGH, gammatz,  rhs_gammatz,  0, 1, n_gammat);

    NewRadX_Apply(cctkGH, tracek,   rhs_tracek,   0, 1, n_trk);

    NewRadX_Apply(cctkGH, axx,      rhs_axx,      1, 1, n_aij);
    NewRadX_Apply(cctkGH, axy,      rhs_axy,      0, 1, n_aij);
    NewRadX_Apply(cctkGH, axz,      rhs_axz,      0, 1, n_aij);
    NewRadX_Apply(cctkGH, ayy,      rhs_ayy,      1, 1, n_aij);
    NewRadX_Apply(cctkGH, ayz,      rhs_ayz,      0, 1, n_aij);
    NewRadX_Apply(cctkGH, azz,      rhs_azz,      1, 1, n_aij);
  }
}

}
